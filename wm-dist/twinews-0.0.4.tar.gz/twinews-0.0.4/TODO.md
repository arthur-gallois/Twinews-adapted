# Crawling

Parmis tous les fails et ceux qui n'ont pas de contenu dans scrap, refaire un crawl avec Selenium
+ faire un click sur bouton dans afterAjaxCallback quand c'est forbes

Repasser sur toute la base pour voir si certains element sont considéré comme des duplicates, à ce moment là, les supprimer

Faire des logs des crawl genre proxy + browser type + status + llongueur du scrap, et pour chaque domain essayer de déduire de ces logs quel stratégie, quel browser est le mieux...

Il faut qu'il y ai tous les types de browser : chrome, phantomjs et http

Faire ça dans la classe Crawler directement avec une base de données mongodb derriere...

# Général

0.0.3 --> score de base sans shortened urls DONE
0.0.4 --> on considère des shortened urls comme des news
getShortenerLovers --> top4 - top3 on prend tous les user ui sont "shortener lovers" DONE
TODOOOOOOOOOO OOOOOOOOO ajouter dans crawlingCallback un ajout dans unshortener...
TODO refaire tout depuis le début car il y a de nouveaux user
0.0.5 --> avec une estimation du nombre de news basé sur les quelques urls deja unshortenées


0.0.10 : truc classique complet mais sans les shortned urls, comme 0.0.3 mais mis à jour


TODO Rassembler le top des liens par domain pour voir si on rate des shortenres inconnus ou des sites de news particuliers



Utiliser reduceIrrelevantUrls :
 * c'est pas une news ou TODO on a la news deja dans newscrawl ==> on suppr le html
 * sinon on laisse


# Ensuite

TODO On peut rééssayer avec d'autres ips et selenium, faire une iteration du SerializableDict newscrawlfails

TODO IMPORANT Baisser de 1 tous les élements de failsSD pour qu'il recommence une fois (faire une fonction)

TODO télécharger les mise à jour des meilleurs users.




# Plus tard

TODO prendre ceux qui interagissent le plus en priorité dans getHoverCandidates ??

TODO faire en sorte de toujours prendre le max dans les amis pour faire une grande communauté...



# TwitterDataset

TODO faire une extaction de dataset : on fait un dump usercrawl en suprimant quelques champs (donc un conversion)
Anonimiser tous les @ ainsi que les user_id
faire plusieurs collections avec des ids...
Faire une extraction à part des news qui ne sont pas dans l'ensemble des users... pour qu'il aient plus de news à recommander...


TODO faire un score relatif au dataset, plus un user aura de news deja téléchargé, mieux ce sera de le prendre dans le dataset ????





# Old readme for newscrawler

First we crawl all news : if the url in the tweet is a news (NewsURLFilter class) or is a shortened url (Unshortener class), we crawl it.

Next we decide if each shares is an item according to the presence of the url in the collection and the scrap text is sufficient (ItemHandler).

Before this we have to filter user according to some criterion : he must share different domain url, have tweets with only text...












