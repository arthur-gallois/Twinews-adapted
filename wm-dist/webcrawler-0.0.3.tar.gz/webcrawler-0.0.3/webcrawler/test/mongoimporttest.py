# coding: utf-8

from databasetools.mongo import *

if __name__ == '__main__':
    print("")


