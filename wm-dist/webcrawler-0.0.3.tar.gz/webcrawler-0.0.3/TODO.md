







# TODO Give example of scenarios :
 * 1 : jsut crawl a set of urls
 * 2 : crawl a set of urls and put other urls during the crawling
 * 3 : give start pages and do some research, then find new urls etc... --> need piped messages
Attention, de manière général, bien décomposer en plusieurs scripts la tache de crawling, et bien retenir ce que l'on fait pour ne pas le refaire plusieurs fois (i.e. retenir que tel requete a donné tel lien resultat, dans quel ordre etc...)






########## OTHERS ################


POUR L'API :
lastCrawlingTimestamp
crawling : une liste avec des versions, une methode (humandriver ou autre...), le html, le titre,
Scrapping : un contenu scrappé propre avec pareil une version, une methode etc
deleteAfter : en jours
Le domaine etc
Un type : twitter user ou autre



TODO https://pypi.python.org/pypi/fake-useragent

############### NOTES ################




# Notes : crawler.driver.implicitly_wait(3) marche pas vraiment
# Par contre un sleep et crawler.driver.manage().timeouts().pageLoadTimeout(10); fonctionne


242835 au total





TODO pouvoir dire tel browser prend tel lien en priorité pour respecter l'ordre du spider....

TODO piped message process + piped message with driver killing
