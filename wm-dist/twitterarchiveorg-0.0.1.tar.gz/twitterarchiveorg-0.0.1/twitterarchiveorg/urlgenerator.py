# coding: utf-8

from systemtools.basics import *
from datatools.json import *
from datatools.url import *
from datatools.csvreader import *
from systemtools.file import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.url import *
from newstools.newsurlfilter import *
from unshortener.unshortener import *
import random

def getNewsCount(tweet):
    return len(getNewsFromTweet(tweet))

nufForUrlGenerator = None
def getNewsFromTweet(tweet):
    global nufForUrlGenerator
    if nufForUrlGenerator is None:
        nufForUrlGenerator = NewsURLFilter()
    news = []
    for url in getNormalizedUrlsFromTweet(tweet):
        if nufForUrlGenerator.isNews(url):
            news.append(url)
    return news

def getNormalizedUrlsFromTweet(tweet):
    urls = getFormatedUrlsFromTweet(tweet)
    newUrls = []
    for url in urls:
        newUrls.append(url["normalized_url"])
    return newUrls
    
def getFormatedUrlsFromTweet(current):
    (urls, expandedUrls) = getUrlsFromTweet(current)
    urlParser = URLParser()
    # Then we yield all:
    allUrls = []
    for i in range(len(urls)):
        toYield = \
        {
            "twitter_expanded_url": expandedUrls[i],
            "normalized_url": urlParser.normalize(expandedUrls[i]),
            "twitter_url": urls[i]
        }
        allUrls.append(toYield)
    return allUrls

def getUrlsFromTweet(current):
    urls = []
    expandedUrls = []
    # We get all urls:
    if "entities" in current and current["entities"] is not None:
        (urls, expandedUrls) = getUrlsFromTweetElement(current)
    # If we are on a retweet, we add all url in the original tweet to the url list:
    if "retweeted_status" in current and current["retweeted_status"] is not None:
        (urlsRT, expandedUrlsRT) = getUrlsFromTweetElement(current["retweeted_status"])
        allUrls = list(urls)
        allExpandedUrls = list(expandedUrls)
        for i in range(len(urlsRT)):
            theUrl = urlsRT[i]
            theExpandedUrl = expandedUrlsRT[i]
            if theUrl not in urls:
                allUrls.append(theUrl)
                allExpandedUrls.append(theExpandedUrl)
        urls, expandedUrls = allUrls, allExpandedUrls
    return urls, expandedUrls

def getUrlsFromTweetElement(current):
    """
        This function just get a tweet and extract urls in entities > urls > [ {url, expanded_url} ]
    """
    urls = []
    expandedUrls = []
    if "entities" in current and current["entities"] is not None:
        current = current["entities"]
        if "urls" in current and current["urls"] is not None and len(current["urls"]) > 0:
            for current in current["urls"]:
                if "url" in current \
                and current["url"] is not None \
                and "expanded_url" in current \
                and current["expanded_url"] is not None \
                and current["url"] != "":
                    urls.append(current["url"])
                    expandedUrls.append(current["expanded_url"])
    return (urls, expandedUrls)

class UrlGenerator():
    def __init__(self, sortedGlobPattern, doShuffle=False):
        self.sortedGlobPattern = sortedGlobPattern
        allFiles = sortedGlob(sortedGlobPattern)
        if doShuffle:
            random.shuffle(allFiles)
        self.jr = JsonReader(allFiles)
    

    def __iter__(self):
        # For all tweets:
        for current in self.jr:
            for url in getFormatedUrlsFromTweet(current):
                yield url
                


class NewsUrlGenerator:
    def __init__(self, dataPath, doShuffle=True, logger=None, verbose=True, unshortenerReadOnly=False):
        self.logger = logger
        self.verbose = verbose
        self.doShuffle = doShuffle
        self.nuf = NewsURLFilter(logger=self.logger, verbose=self.verbose, unshortener=Unshortener(logger=self.logger, verbose=self.verbose, readOnly=unshortenerReadOnly))
        self.taoUrlGenerator = UrlGenerator(dataPath, doShuffle=self.doShuffle)
    
    def __iter__(self):
        for theDict in self.taoUrlGenerator:
            normalizedUrl = theDict["normalized_url"]
            if normalizedUrl is not None:
                if self.nuf.isNews(normalizedUrl):
                    yield theDict



def countNews(dataDir, logger=None):
    nug = NewsUrlGenerator(dataDir, logger=logger)
    count = 0
    for current in nug:
        count += 1
        if count % 500 == 0:
            log("count=" + str(count))
            log(current)
    log("Total: " + str(count))

if __name__ == '__main__':
#     dataPath = "/home/hayj/Data/TwitterArchiveOrg/Converted2/*.bz2"
#     u = UrlGenerator(dataPath, doShuffle=False)
#     i = 0
#     for current in u:
#         printLTS(current)
#         i += 1
#         if i > 100:
#             break

    countNews(dataDir() + "/TwitterArchiveOrg/Converted3.3/*.bz2") # 75426 pour Converted3.2 à 30






