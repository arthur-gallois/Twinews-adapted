# coding: utf-8

import splinter
import re
import os
from requests import get
from systemtools.system import bash
import urllib.request, urllib.error, urllib.parse

from networktools import ipgetter


# DEPRECATED

def getIP():
    return ipgetter.myip()

def checkIP(ip=None, useFirefox=False):
    ip1 = ipgetter.myip()
    print("ipgetter: " + ip1)
    
    ip4 = get('https://api.ipify.org').text
    print("api.ipify.org: " + ip4)
    
    browserName = 'phantomjs'
    browser = splinter.Browser(browserName)
    
    ip3 = browser.visit("http://www.localiser-ip.com")
    ip3 = browser.html
    ip3 = re.search("\d+[.]\d+[.]\d+[.]\d+", ip3).group(0)
    print(browserName + " and localiser-ip.com: " + ip3)
    
    if useFirefox:
        browser.quit()
        browserName = 'firefox'
        browser = splinter.Browser(browserName)

    ip2 = browser.visit("https://www.adresseip.com")
    ip2 = browser.html
    ip2 = re.search("\d+[.]\d+[.]\d+[.]\d+", ip2).group(0)
    browser.quit()
    print(browserName + " and adresseip.com: " + ip2)
    
    if ip is None:
        assert ip1 == ip2
        assert ip2 == ip3
        assert ip3 == ip4
    else:
        assert ip == ip1
        assert ip == ip2
        assert ip == ip3
        assert ip == ip4
    
def setProxy2(host, port="80", user="octopeek", password="librepost"):
    """
    Doesn't work
    """
    exports = \
    [
        'export http_proxy="http://' + user + ':' + password + '@' + host + ':' + port + '"',
        'export https_proxy="http://' + user + ':' + password + '@' + host + ':' + port + '"',
        'export ftp_proxy="http://' + user + ':' + password + '@' + host + ':' + port + '"',
        'export socks_proxy="http://' + user + ':' + password + '@' + host + ':' + port + '"',
        'export all_proxy="http://' + user + ':' + password + '@' + host + ':' + port + '"',
    ]
    for export in exports:
        print(export)
        print(bash(export))

def setProxy(host, port="80", user="octopeek", password="librepost"):
    exports = \
    {
        'http_proxy': 'http://' + user + ':' + password + '@' + host + ':' + port,
        'https_proxy': 'http://' + user + ':' + password + '@' + host + ':' + port,
        'ftp_proxy': 'http://' + user + ':' + password + '@' + host + ':' + port,
        'socks_proxy': 'http://' + user + ':' + password + '@' + host + ':' + port,
        'all_proxy': 'http://' + user + ':' + password + '@' + host + ':' + port,
    }
    for key, value in list(exports.items()):
        os.environ[key] = value


def setProxy3(host, port="80", user="octopeek", password="librepost"):
    """
    Doesn't work
    """

    proxy_info = \
    {
        'user' : user,
        'pass' : password,
        'host' : host,
        'port' : int(port) # or 8080 or whatever
    }
     
    # build a new opener that uses a proxy requiring authorization
    proxy_support = urllib.request.ProxyHandler({"http" : \
    "http://%(user)s:%(pass)s@%(host)s:%(port)d" % proxy_info})
    opener = urllib.request.build_opener(proxy_support, urllib.request.HTTPHandler)
    
   
    # install it
    urllib.request.install_opener(opener)
    
    # use it
#     f = urllib2.urlopen('http://www.python.org/')
#     print f.headers
#     print f.read()



if __name__ == '__main__':
#     checkIP()
    setProxy("181.214.212.10")
    checkIP("181.214.212.10")
    print("end")
    
    
    
    
    
    
    
    
