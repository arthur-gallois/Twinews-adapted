
## Installation (Python 3)

	git clone https://github.com/hayj/NLPTools.git
	pip install ./NLPTools/wm-dist/*.tar.gz

## Usage

See the code to have more information:

	>>> from nlptools.langrecognizer import *
	>>> from nlptools.basics import *
	>>> from nlptools.tokenizer import *

