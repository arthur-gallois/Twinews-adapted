mkdir -p ./data
cp /home/hayj/Data/Misc/news-website-list/data/* ./data/