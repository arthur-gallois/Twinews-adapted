# Unshortener

TODO IMPORANT Faire un score version 0.0.4 en mettant un shortened urls comme des news, puis parcourir le top, prendre le TwitterUser et unshortener toutes les urls

TODO pour unshortener faire plusieurs tor service sur different port et intergrer ça à httpbrowser, et le bandit relance tous les services

WARNING: set unshortenerReadOnly as False


Utiliser reduceIrrelevantUrls :
 * c'est pas une news ou TODO on a la news deja dans newscrawl ==> on suppr le html
 * sinon on laisse

# NewsCrawler


Ne pas mettre beaucoup de parallel request, il va suffisaement vite...

# TwitterCrawler

TODO prendre ceux qui interagissent le plus en priorité dans getHoverCandidates ??

TODO supprimer des user de la base pour qu'ils soient rescrapés ?

TODO faire en sorte de toujours prendre le max dans les amis pour faire une grande communauté...

# TwitterDataset


 * faire une extaction de dataset : on fait un dump usercrawl en suprimant quelques champs (donc un conversion)
Pour la conversion : Faire simplement un dict de description qui garde que ce qui est présent, et met des None s'il n'y a pas...
 * on fait un dump d'une sous partie des news, ceux correspondants aux users selectionnés
 * puis les news autres qui permettent un entrainement aussi, et plus de recommandations...
 * Faire aussi les hoveruser ? Non pas pour l'instant
 * Anonimiser tous les @ ainsi que les user_id

# URL failed

On peut rééssayer avec d'autres ips et selenium, faire une iteration du SerializableDict newscrawlfails

TODO IMPORANT Baisser de 1 tous les élements de failsSD pour qu'il recommence une fois (faire une fonction)

# TwitterScore

TODO faire un score relatif au dataset, plus un user aura de news deja téléchargé, mieux ce sera de le prendre dans le dataset

