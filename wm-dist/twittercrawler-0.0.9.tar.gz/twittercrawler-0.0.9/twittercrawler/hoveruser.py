from systemtools.logger import *
from nlptools.langrecognizer import *
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from scroller.scroller import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from hjwebbrowser.utils import *
from twittercrawler import __version__
from twittercrawler.utils import *
from bs4 import BeautifulSoup


def getHoverProfilText(*args, **kwargs):
    element = getHoverProfilElement(*args, **kwargs)
    try:
        if element is not None:
            return element.text
    except Exception as e:
        logException(e, obj=None, location="getHoverProfilText")
    return None

def getHoverProfilSource(*args, **kwargs):
    element = getHoverProfilElement(*args, **kwargs)
    try:
        if element is not None:
            return element.get_attribute('outerHTML')
    except Exception as e:
        logException(e, obj=None, location="getHoverProfilText")
    return None

def getHoverProfilElement(driver, hoverId="#profile-hover-container"):
    try:
        return driver.find_element_by_css_selector(hoverId)
    except:
        return None

def getAllAtrepliesElements \
(
    driver,
    cssSelectors=\
    [
        "#timeline a.twitter-atreply.pretty-link.js-nav",
        "#timeline a.account-group.js-account-group.js-action-profile.js-user-profile-link.js-nav",
        "#timeline .QuoteTweet-innerContainer"
        "#timeline a.pretty-link.js-user-profile-link"
    ],
    userIdAttrs=["data-user-id", "data-mentioned-user-id"],
    reverse=True,
):
    """
        This function return the set (no duplicates on username)
        of users hover links elements in reverse order with :
        [(element, name, yLocation), ...]
        The yLocation can be recalculate for fresh version by using
        element.location["y"]
    """
    allElements = []
    for cssSelector in cssSelectors:
        try:
            for element in driver.find_elements_by_css_selector(cssSelector):
                attrAlreadyGot = False
                for attrName in userIdAttrs:
                    if not attrAlreadyGot:
                        userId = element.get_attribute(attrName)
#                         print(element.get_attribute('outerHTML'))
                        if userId is not None:
                            attrAlreadyGot = True
                            yLocation = element.location["y"]
                            newAllElements = []
                            for (currentElement, currentUserId, currentYLocation) in allElements:
                                if currentUserId != userId:
                                    newAllElements.append((currentElement, currentUserId, currentYLocation))
                            allElements = newAllElements
                            allElements.append((element, userId, yLocation))
        except Exception as e:
            logException(e, location="getAllAtrepliesElements")
    return sortBy(allElements, desc=reverse, index=2)

previousHoverText = None
def waitForHover(driver, ajaxSleep=6.0, totalIntervals=100):
    global previousHoverText
    for i in range(totalIntervals):
        text = getHoverProfilText(driver)
        if text is None or len(text.strip()) < 2 or text == previousHoverText:
            time.sleep(ajaxSleep / float(totalIntervals))
        else:
            previousHoverText = text
            return True
    return False

def randomMove(driver, element, logger=None):
    try:
        (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
        randomX = getRandomInt(-400, -100)
        randomY = getRandomInt(0, 100)
        action = webdriver.ActionChains(driver)
        action.move_to_element_with_offset(element, randomX, randomY)
        action.perform()
    except Exception as e:
        logException(e, logger, location="randomMove")

def goOutOfHover(driver, element, ajaxWait=10.0, totalIntervals=100, logger=None):
    for i in range(totalIntervals):
        text = getHoverProfilText(driver)
        if text is None or len(text.strip()) < 2:
            return True
        else:
            randomMove(driver, element, logger=logger)
            time.sleep(ajaxWait / float(totalIntervals))
    return False


def getAllHoverSources(driver, *args, ajaxWait=6.0, beforeMoveWait=0.1, afterMoveWait=0.1, **kwargs):
    userHovers = getAllAtrepliesElements(driver, *args, **kwargs)
    printLTS(userHovers)
    allSources = []
    for (element, _, _) in userHovers:
        randomSleep(beforeMoveWait)
        action = webdriver.ActionChains(driver)
        action.move_to_element(element)
        action.perform()
        randomSleep(afterMoveWait)
        totalIntervals = 100
        for i in range(totalIntervals):
            text = getHoverProfilText(driver)
            if text is None or len(text.strip()) < 2:
                time.sleep(ajaxWait / float(totalIntervals))
            else:
                break
        currentSource = getHoverProfilSource(driver)
        if currentSource not in allSources:
            allSources.append(currentSource)
    return allSources


globalHoverUserCollection = None
class HoverUserScroller:
    """
        We need this class because the crawling will be redirected to high pagerank user
        so we need hover user data to filter user to crawl after the current one
    """
    def __init__(self,
                    logger=None,
                    verbose=True,
                    hoverUserCollection=None,
                    mongoUser="hayj",
                    mongoHostname="datascience01",
                    dbName="twitter",
                    collectionName="hoverusers"):
        global globalHoverUserCollection
        self.logger = logger
        self.verbose = verbose
        self.urlParser = URLParser(logger=self.logger, verbose=self.verbose)
        self.hoverUserCollection = hoverUserCollection
        if self.hoverUserCollection is None:
            if globalHoverUserCollection is None:
                (user, password, host) = getMongoAuth(user=mongoUser, hostname=mongoHostname)
                self.hoverUserCollection = MongoCollection \
                (
                    dbName,
                    collectionName,
                    version=__version__,
                    indexOn="user_id",
                    giveTimestamp=True,
                    logger=self.logger,
                    verbose=self.verbose,
                    user=user, password=password, host=host,
                )
                globalHoverUserCollection = self.hoverUserCollection
            else:
                self.hoverUserCollection = globalHoverUserCollection
        self.userIdAlreadyHovered = set()
        self.twitterUrl = "https://twitter.com"

    def parseHoverUser(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        data = {}
        data["username"] = getSoupText(soup, ".username b")
        data["tweet_count"] = getFirstNumber(getSoupAttr(soup, "data-count", ".ProfileCardStats a[data-element-term=\"tweet_stats\"] .ProfileCardStats-statValue"))
        data["following_count"] = getFirstNumber(getSoupAttr(soup, "data-count", ".ProfileCardStats a[data-element-term=\"following_stats\"] .ProfileCardStats-statValue"))
        data["follower_count"] = getFirstNumber(getSoupAttr(soup, "data-count", ".ProfileCardStats a[data-element-term=\"follower_stats\"] .ProfileCardStats-statValue"))
        data["bio"] = getSoupText(soup, ".bio.profile-field.u-dir")
        data["user_id"] = getSoupAttr(soup, "data-user-id", "#profile-hover-container")
        data["associated_tweet_id"] = getSoupAttr(soup, "data-associated-tweet-id", "#profile-hover-container")
        data["username"] = getSoupAttr(soup, "data-screen-name", ".ProfileCard-content")
        data["name"] = getSoupText(soup, "a.fullname.ProfileNameTruncated-link")
        data["url"] = self.urlParser.join(self.twitterUrl,
                        getSoupAttr(soup, "href", "a.fullname"))
        return data

    def scroll \
    (
        self,
        driver,
        stopFunct=None,
        sequence=3,
        distance=10000000,
        getAllAtrepliesElementsParams={},
        distancePerSecond=10000, # 10000
        tooOldDayCount=30,
        basicActionMinSleep=0.0001,
        maxHoverFail=2,
        source=None,
        sourceType=None,
        waitForHoverDuration=6.0,
        maxHoverCandidatesPerPage=5,
        maxHoverPerPage=100,
        hoverUserPrintProb=0.2,
        maxHoverFailed=20,
    ):
        """
            This function take a driver and scroll down during hover user scraping
        """
        # We init the data to return:
        hoverUsersData = []
        # We check if it is a Browser instance:
        if isinstance(driver, Browser):
            driver = driver.driver
        # We get first data about the page:
        (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
        minScrollTopReached = scrollTop
        maxScrollBottomReached = scrollBottom
        totalDistance = 0
        # Here while stopFunct return False and the distance max is not reached:
        started = False
        # We create the fail structure:
        hoverUsersFailedEnough = {}
        # While we have candidates to scrap and we continue:
        while not (countHoverUsersCandidates(hoverUsersData) >= maxHoverCandidatesPerPage) and \
        scrollContinueCondition \
        (
            started,
            stopFunct,
            driver,
            totalDistance,
            minScrollTopReached,
            maxScrollBottomReached,
            distance,
        ):
            started = True
            # We check the length of failed hovers:
            if len(hoverUsersFailedEnough) > maxHoverFailed:
                logError("We have too much hover fail!!!", self)
                break
            for i in range(sequence):
                # Here we break if we have enough hover users:
                if countHoverUsersCandidates(hoverUsersData, logger=self.logger, verbose=self.verbose) >= maxHoverCandidatesPerPage:
                    break
                # Here we break if there are too much hover users (security check):
                if len(hoverUsersData) > maxHoverPerPage:
                    break
                # Here we get all hover users
                hoverUsers = getAllAtrepliesElements(driver, reverse=False, **getAllAtrepliesElementsParams) # 1 second duration
                # For each user in top down order:
                for (element, userId, y) in hoverUsers:
                    # Here we break if we have enough hover users:
                    if countHoverUsersCandidates(hoverUsersData, logger=self.logger, verbose=self.verbose) >= maxHoverCandidatesPerPage:
                        break
                    # If we didn't scrap this user yet:
                    if userId not in self.userIdAlreadyHovered and (userId not in hoverUsersFailedEnough or hoverUsersFailedEnough[userId] < maxHoverFail):
                        # We scrap only if the user is not in the collection
                        # Or if it is too old
                        toScrap = True
                        query = {"user_id": userId}
                        row = self.hoverUserCollection.findOne(query)
                        if row is not None:
                            # If the previous scrap is 1 month old:
                            if row["timestamp"] < time.time() - 60 * 60 * 24 * tooOldDayCount:
                                toScrap = True
                            else:
                                toScrap = False
                        else:
                            toScrap = True
                        if toScrap:
                            try:
                                # We first scroll to the element:
                                scrollTo(driver, element, distancePerSecond=distancePerSecond)
                                # Then we move to the element
                                randomSleep(basicActionMinSleep)
                                moveTo(driver, element)
                                # Then we wait for the hover:
                                hoverFound = waitForHover(driver, ajaxSleep=waitForHoverDuration)
                                if hoverFound:
                                    # Then we scrap the hover data:
                                    hoverUserData = {}
                                    randomSleep(basicActionMinSleep)
                                    hoverUserData["version"] = __version__
                                    hoverUserData["source"] = source
                                    hoverUserData["source_type"] = sourceType
                                    hoverUserData["html"] = getHoverProfilSource(driver)
                                    hoverUserData["user_id"] = userId
                                    hoverUserData["scrap"] = self.parseHoverUser(hoverUserData["html"])
                                    hoverUserData["url"] = hoverUserData["scrap"]["url"]
                                    # We check variables:
                                    if hoverUserData["scrap"]["following_count"] is None or \
                                       hoverUserData["scrap"]["follower_count"] is None or \
                                       hoverUserData["scrap"]["tweet_count"] is None:
                                        logError("We don't have any count from the hover user, html data:", self)
                                        logError(hoverUserData["html"], self)
                                    # Now we go out of the current hover user:
                                    if not goOutOfHover(driver, element):
                                        logError("Can't go out of the current hover user!", self)
                                    # Juste en dessous de ce commentaire, il y a une instruction qui prend 2 secondes quand la page est grosse.
                                    # if all is ok:
                                    if dictContains(hoverUserData, "scrap") and \
                                    dictContains(hoverUserData, "user_id") and \
                                    dictContains(hoverUserData["scrap"], "user_id") and \
                                    dictContains(hoverUserData, "html") and \
                                    dictContains(hoverUserData["scrap"], "following_count") and \
                                    dictContains(hoverUserData["scrap"], "follower_count") and \
                                    dictContains(hoverUserData["scrap"], "tweet_count"):
                                        if hoverUserData["scrap"]["user_id"] != userId:
                                            logError("The scrap user_id is " + str(hoverUserData["scrap"]["user_id"]) + " and the link user_id is " + str(userId), self)
                                        else:
                                            # We delete the user from the database if all is ok:
                                            if row is not None:
                                                self.hoverUserCollection.deleteOne(query)
                                            # Now we store the data:
                                            self.hoverUserCollection.insert(hoverUserData)
                                            # We add it in userIdAlreadyHovered:
                                            self.userIdAlreadyHovered.add(userId)
                                            # And finally we add the user to the list:
                                            hoverUsersData.append(hoverUserData)
                                            # And we print it:
                                            if getRandomFloat() < hoverUserPrintProb:
                                                if not dictContains(hoverUserData["scrap"], "username"):
                                                    logError("hoverUserData has no username!", self)
                                                else:
                                                    log("We just scraped hover user " +
                                                        hoverUserData["scrap"]["username"] + " and others.", self)
                                    else:
                                        if userId not in hoverUsersFailedEnough:
                                            hoverUsersFailedEnough[userId] = 0
                                        hoverUsersFailedEnough[userId] += 1
                                        logError("hover data cannot be parsed!", self)
                                else:
                                    if userId not in hoverUsersFailedEnough:
                                        hoverUsersFailedEnough[userId] = 0
                                    hoverUsersFailedEnough[userId] += 1
                                    log("hover not found!", self)
                            except Exception as e:
                                logException(e, self, location="HoverUserScroller instance's scroll method")
            # Here we just scrolled over all hover user, so now we just need to scroll until the bottom of the page
            smartScroll \
            (
                driver,
                stopFunct=None,
                distance=15000,
                sequence=100,
                stopAtBorder=True,
                distancePerSecond=distancePerSecond,
                logger=self.logger,
                verbose=self.verbose,
                down=True,
                timeout=30,
                reverseScrollProb=0.1,
            )
            # And we update all infos:
            (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
            if scrollTop < minScrollTopReached:
                minScrollTopReached = scrollTop
            if scrollBottom > maxScrollBottomReached:
                maxScrollBottomReached = scrollBottom
            totalDistance = (maxScrollBottomReached - windowHeight) - minScrollTopReached
        # Here we just finished to scrap all hover users, so we finish the scroll:
        smartScroll \
        (
            driver,
            stopFunct=stopFunct,
            distance=None,
            sequence=100,
            stopAtBorder=False,
            distancePerSecond=distancePerSecond,
            logger=self.logger,
            verbose=self.verbose,
            down=True,
            timeout=3600,
            reverseScrollProb=0.1,
            reverseScrollDistance=None,
            reverseScrollEachTraveledDistance=30000,
        )
        # Here all is scrapped and we reach the bottom of the user or the stop function detected too old tweets, so we just return the data:
        return hoverUsersData



def countHoverUsersCandidates(hoverUsersData, *args, **kwargs):
    count = 0
    for current in hoverUsersData:
        if isHoverUsercandidate(current, *args, **kwargs):
            count += 1
    return count

def isHoverUsercandidate \
(
    hoverUser,
    collection=None,
    minFollowers=2,
    maxFollowers=3000,
    minFollowing=10,
    maxFollowing=10000,
    minTweetCount=30,
    maxTweetCount=1000000,
    logger=None, verbose=True,
):
    if dictContains(hoverUser, "scrap"):
        hoverUser = hoverUser["scrap"]
        if collection is None or not collection.has(hoverUser["user_id"]):
            # We try to access hover user to determine if this is a candidate:
            try:
                followerCount = int(hoverUser["follower_count"])
                followingCount = int(hoverUser["following_count"])
                tweetCount = int(hoverUser["tweet_count"])
                if minFollowing <= followingCount and \
                followingCount <= maxFollowing and \
                minTweetCount <= tweetCount and \
                tweetCount <= maxTweetCount and \
                minFollowers <= followerCount and \
                followerCount <= maxFollowers:
                    return True
            except Exception as e:
                logException(e, location="Can't access hover user data!", logger=logger, verbose=verbose)
    return False

def getHoverCandidates \
(
    userData,
    tus,
    maxHoverCandidates=10,
    *args, **kwargs
):
    if userData is None or \
    "hover_users" not in userData or \
    len(userData["hover_users"]) == 0:
        return []
    result = []
    score = crawlingCandidateScore(userData, tus)
    if score == 1.0:
        hoverUsers = userData["hover_users"]
        random.shuffle(hoverUsers)
        for hoverUser in hoverUsers:
            if isHoverUsercandidate(hoverUser, *args, **kwargs):
                result.append(hoverUser["url"])
            if len(result) > maxHoverCandidates:
                break
    return result

