# nn pew in twittercrawler-venv python ~/wm-dist-tmp/TwitterCrawler/twittercrawler/mongoanalysis.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *


def scrapTest(url="https://twitter.com/EviStamatiou1"):
    b = Browser(driverType=DRIVER_TYPE.chrome)
    b.html(url)
    tus = TwitterScraper \
    (
        dateLimit="23/12/2017",
        oldTweetsMax=2,
        stopSignalCountMax=1,
        sleepSignalDuration=1,
        logger=None,
        verbose=True,
        name=b.name,
    )
    tus.scrollUserPage(b.driver)
    userData = tus.scrapUser(b.driver)
    reducedUserData = reduceUserCrawlRow(userData, deleteTweets=True)
    printLTS(reducedUserData)

def seeLocations():
    for current in collection.find():
        print(current["scrap"]["location"])


def renameDatabase():
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    collection = MongoCollection \
    (
        "twitter",
        "usercrawl",
        user=user, host=host, password=password,
    )
    collection.showDbs()
    collection.rename("usercrawl_old2")
    collection.showDbs()

from twittercrawler.usercrawler import *

def getAllAllowedUsers():
    tus = TwitterScraper()
    allUrls = []
    for row in collection.find():
        isEnUser = tus.getEnRatio(row) >= 0.8
        followerCount = row["scrap"]["follower_count"]
        thisIsAnUsaUser = isUsaUser(row)
        allowedAtreplies = allowCrawlerPut(isEnUser, followerCount, thisIsAnUsaUser)
        if allowedAtreplies > 0:
            allUrls.append(row["last_url"])
            for current in row["safe_atreplies"]:
                allUrls.append(current["url"])
        print(len(allUrls))
    for current in allUrls:
        print(current)
#             print(location)
#             print(isUsaUser(row))
#             print()

def testX():

#     a = set(getStartUrls())
#     for current in a:
#         print(current)
#     exit()
    # Mongo collection init:
    maxAtrepliesPerPage = 5
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    dbName = "twitter"
    collectionName = "usercrawl_old1"
    collection = MongoCollection \
    (
        dbName,
        collectionName,
        version=__version__,
        user=user, host=host, password=password,
    )
#     getAllAllowedUsers()
#
#     exit()

    collection.show()
#     seeLocations()
    exit()

    for row in collection.find():
        printLTS(reduceUserCrawlRow(row))
        exit()

    # collection.show(10, sort=("timestamp", pymongo.DESCENDING))

def seeUsers():
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    collection = MongoCollection \
    (
        "twitter",
        "usercrawl",
        user=user, host=host, password=password,
    )
    for row in collection.find():
        printLTS(reduceUserCrawlRow(row, deleteTweets=True))

def showDbs():
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    collection = MongoCollection \
    (
        "twitter",
        "usercrawl",
        user=user, host=host, password=password,
    )
#     collection.show(100)
    collection.showDbs()

def countBlocked():
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    collection = MongoCollection \
    (
        "twitter",
        "usercrawl",
        user=user, host=host, password=password,
    )
    print("blocked count: " + str(collection.find({"scrap.blocked": True}).count()))
    print("not blocked count: " + str(collection.find({"scrap.blocked": False}).count()))


def countPageStates(collection):
    for current in PAGE_STATE:
        current = current.name
        print(current + " count: " + str(collection.find({"scrap.page_state": current}).count()))

def multipleStats():
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    notUniqueIndexes = \
    [
#         "scrap.page_state",
        "scrap.has_enough_old_tweets",
#         "date_limit",
        "version",
        "hostname",
    ]
    collection = MongoCollection \
    (
        "twitter",
        "usercrawl",
        user=user, host=host, password=password,
        indexNotUniqueOn=notUniqueIndexes,
        indexOn=["user_id", "url"],
    )
    for key in notUniqueIndexes:
        for value in collection.collection.distinct(key):
            count = collection.collection.count({key: value})
            print(key + " " + str(value) + ": " + str(count))
        print()

def miseAJourNouvelleVersionCrawler():
    if isHostname("datasc"):
        (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
        collection = MongoCollection \
        (
            "twitter",
            "usercrawl",
            user=user, host=host, password=password,
        )
        collection.update({"timestamp": {"$lt": 1521207298.0}}, {"$rename": {"crawler": "browser"}, "$set": {"last_url_domain": "twitter.com", "domain": "twitter.com"}})
    else:
        print("exec on datascience01")

def updateTest():
    if isHostname("hjlat"):
        collection = MongoCollection \
        (
            "twitter",
            "hoverusers",
            host="localhost",
        )
        collection.update({"timestamp": {"$lt": 1621207298.0}}, {"$rename": {"aaa": "test"}, "$set": {"last_url_domain": "twitter.com", "domain": "twitter.com"}})
    else:
        print("exec on hjlat")

def deleteBadHoverUsers():
    if isHostname("datasc"):
        (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
        collection = MongoCollection \
        (
            "twitter",
            "hoverusers",
            user=user, host=host, password=password,
        )
        collection.delete({"scrap.following_count": None})
    else:
        print("exec on datascience01")

# db.getCollection('usercrawl').find({}).sort({timestamp: -1})

if __name__ == '__main__':
#     strToTmpFile("", "miseAJourNouvelleVersionCrawler.started")
#     print("STARTING")
#     miseAJourNouvelleVersionCrawler()
#     print("DONE")
#     strToTmpFile("", "miseAJourNouvelleVersionCrawler.finished")


#     updateTest()



    multipleStats()


#     deleteBadHoverUsers()


