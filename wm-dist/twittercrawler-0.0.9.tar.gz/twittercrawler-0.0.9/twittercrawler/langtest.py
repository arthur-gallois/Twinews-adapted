# coding: utf-8

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *
from twittercrawler.utils import *

tweets = \
[
    "¡Atención! ¡Ya a la venta! @JRhodesPianist en @AuditorioZGZ 20 marzo Sala Mozart",
    "Estos pimientos! ",
    "https://compraentradas.zaragoza.es  #ZGZesCultura #Venalauditori",
    "Confidence and bold decisions! (and read the script 200 times, it helps with the former two)https://twitter.com/SpotlightUK/status/959435247203962880 …",
    "Thank you @EngRoseBoutique !https://twitter.com/EngRoseBoutique/status/959435415940927489 …",
    "中国语文",
    "¡Atención! ¡Ya a la venta! @JRhodesPianist en @AuditorioZGZ 20 marzo Sala Mozart this is a big problem !!! #problem",
    "Ну что, поехали под облака? #Невысоко, зато длинно, 17 км 5%",
    "Провластные митинги пройдут сегодня во многих российских @test",
    "Провластные митинги пройдут сегодня во многих российских http://города.com",
    "Провластные this is a good solution http://города.com",
    "Провластные !this! !is! !a! !good! !solution! http://города.com",
    "!this! !is! !a! !good! !solution! http://города.com",
    "No you're wiping away a tear...",
    "Feels like I just woke up in an alternative universe.", # Doesn't works
    "VW seeks US emissions trial delay after ‘prejudicial’.", # Doesn't works
    "Hello old friend (part I) …", # Doesn't works
    "Surprise!", # Doesn't works
    "Yeaaah …", # Doesn't works
    "Thank you …", # Doesn't works
    "Thank you", # Doesn't works
]


def testCleanTweet():
    for tweetText in tweets:
        print(tweetText)
        print(cleanTweetText(tweetText))
        print(recognize(cleanTweetText(tweetText)))
        print()

def testScrap2():
    html = fileToStr("/home/hayj/tmp/J17WT4TFWF-15179404804532537")
    ts = TwitterScraper()
    userData = ts.scrapUser(html)
    tweets = userData["tweets"]
    for tweet in tweets:
        print(tweet["text"])
#         if tweet["tweet_id"] is None:
#             print("yo")

def testScrap():
    for row in collection.find():
        ts = TwitterScraper()
        userData = ts.scrapUser(row["html"])
        tweets = userData["tweets"]
        for tweet in tweets:
            if tweet["tweet_id"] is None:
#                 printLTS(tweet)
#                 printLTS(row)
                exit()

def langTest1():
    for row in collection.find():
        ts = TwitterScraper()
#         userData = ts.scrapUser(row["html"])
#         isEnUser = ts.isEnUser(row["html"])
        enRatio = ts.getEnRatio(row)
        if enRatio > 0.0 and enRatio < 0.6:
            for tweet in row["scrap"]["tweets"]:
                print(tweet["text"])
            print("\n\n")
            print(enRatio)
            print("\n\n\n\n\n\n\n\n")
            input()

def langTest2():
    i = 0
    for row in collection.find():
        l = LangRecognizer()
        for tweet in row["scrap"]["tweets"]:
            text = cleanTweetText(tweet["text"])
            lang = l.recognize(text)
            if lang is not None and lang != "en":
                print(text)
                print(lang)
                print()
                print("----------")
                print()
                i += 1
                if i % 50 == 0:
                    input()

if __name__ == '__main__':
    # Mongo collection init:
    (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    dbName = "twitter"
    collectionName = "usercrawl"
    collection = MongoCollection \
    (
        dbName,
        collectionName,
        user=user, host=host, password=password,
    )

    langTest1()
    exit()

