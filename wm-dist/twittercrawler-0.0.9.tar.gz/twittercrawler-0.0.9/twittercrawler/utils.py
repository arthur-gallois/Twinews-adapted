from systemtools.logger import *
from nlptools.langrecognizer import *
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from scroller.scroller import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from hjwebbrowser.utils import *
from twittercrawler import __version__






def getSoupText(soup, cssSelector=None):
    if cssSelector is not None:
        soup = soup.select_one(cssSelector)
    if soup is None:
        return None
    else:
        text = soup.getText()
        if text is None:
            return None
        else:
            text = text.strip()
            if text == "":
                return None
            else:
                return text.strip()

def getSoupAttr(soup, attr, cssSelector=None):
    if cssSelector is not None:
        soup = soup.select_one(cssSelector)
    if soup is None:
        return None
    else:
        if soup.has_attr(attr):
            return soup[attr]
        else:
            return None




def cleanTweetText(tweetText, logger=None, verbose=True):
    if tweetText is None:
        return None
    tweetText = ' '.join(re.sub("([#@][A-Za-z0-9]+)|(\w+:\/\/\S+)", " ", tweetText).split())
    tweetText = removePunctSafe(tweetText)
    tweetText = tweetText.strip()
    return tweetText

def removePunctSafe(text):
    if text is None:
        return None
    return re.sub("[!?.;:…/*)([\]=+-]", " ", text)

def reduceUserCrawlRow(row, deleteTweets=False):
    data = {}
    data["tweets"] = []
    scrap = row
    if "scrap" in scrap:
        scrap = scrap["scrap"]
    for tweet in scrap["tweets"]:
        dataTweet = {}
        dataTweet["type"] = tweet["type"]
        dataTweet["text"] = tweet["text"]
        dataTweet["date"] = tweet["date"]
        dataTweet["username"] = tweet["username"]
        data["tweets"].append(dataTweet)
    data["url"] = scrap["url"]
    data["tweets_en_ratio"] = scrap["tweets_en_ratio"]
    data["scraped_tweet_count"] = len(data["tweets"])
    data["tweet_count"] = scrap["tweet_count"]
    data["username"] = scrap["username"]
    data["verified"] = scrap["verified"]
    if dictContains(scrap, "page_state"):
        data["page_state"] = scrap["page_state"]
    if dictContains(scrap, "has_enough_old_tweets"):
        data["has_enough_old_tweets"] = scrap["has_enough_old_tweets"]
    if deleteTweets:
        del data["tweets"]
    return data

usaLocationVoc = None
def initUsaLocation(dataDirPath=None):
    global usaLocationVoc
    if usaLocationVoc is None:
        usaLocationVoc = []
        if dataDirPath is None:
            dataDirPath = dataDir() + "/Misc/location"
        for fileName in ["usa-states.txt", "usa-biggest-cities.txt"]:
            data = fileToStrList(dataDirPath + "/" + fileName)
            loweredData = []
            for current in data:
                if current is not None and len(current) > 2:
                    loweredData.append(current.lower())
            usaLocationVoc += loweredData
        usaLocationVoc.append("usa")

def getStartUrls(filePath=None):
    if filePath is None:
        filePath = dataDir() + "/Misc/crawling/twitter/usa-start-urls.txt"
    startUrls = fileToStrList(filePath)
    random.shuffle(startUrls)
    return startUrls


def isUsaUser(row, *args, **kwargs):
    global usaLocationVoc
    if "scrap" in row:
        row = row["scrap"]
    if not dictContains(row, "location"):
        return False
    else:
        initUsaLocation(*args, **kwargs)
        location = row["location"].lower()
        for current in usaLocationVoc:
            if current in location:
                return True
    return False



PAGE_STATE = Enum("PAGE_STATE", "blocked loading hasMoreItems backToTop hasFewItems unknown protected")
def getPageState(soup, logger=None, verbose=True):
    try:
        streamFailContainerSoup = soup.select_one(".stream-fail-container")
        if "u-hidden" not in streamFailContainerSoup["class"]:
            if getSoupAttr(streamFailContainerSoup, "style") is None:
                return PAGE_STATE.loading
            elif "display: block" in getSoupAttr(streamFailContainerSoup, "style") and \
            "has-items-error" in soup.select_one(".stream-footer .timeline-end.has-items.has-more-items")["class"]:
                return PAGE_STATE.blocked
        else:
            if soup.select_one(".stream-footer .has-more-items") is not None:
                return PAGE_STATE.hasMoreItems
            elif getSoupAttr(soup, "style", "button.back-to-top") is None:
                return PAGE_STATE.hasFewItems
            elif "display: inline-block" in getSoupAttr(soup, "style", "button.back-to-top"):
                return PAGE_STATE.backToTop
    except Exception as e:
        if soup.select_one(".ProtectedTimeline .ProtectedTimeline-heading") is not None:
            return PAGE_STATE.protected
        else:
            logException(e, location="getPageState", logger=logger, verbose=verbose)
    return PAGE_STATE.unknown





def crawlingCandidateScore \
(
    userData,
    tus,
    maxFollowers=3000,
    test=False,
):
    """
        For the moment, this function allow only english USA users with less
        than maxFollowersAllowed followers to put atreplies in the crawler queue
    """
    if userData is None or not dictContains(userData, "user_id"):
        logError("userData not conform!!!!!!!!!!!!!!!!!!!!!")
        return 0.0
    isEnUser = tus.isEnUser(userData)
    followerCount = userData["follower_count"]
    thisIsAnUsaUser = isUsaUser(userData)
    if test:
        return random.choice([0.0, 1.0])
    if not isEnUser:
        return 0.0
    if not thisIsAnUsaUser:
        return 0.0
    if followerCount > maxFollowers:
        return 0.0
    return 1.0

def dateToTimestamp(theDate):
    return time.mktime(datetime.strptime(theDate, "%d/%m/%Y").timetuple())

def hasEnoughOldTweets(data, dateLimit=None, oldTweetsMax=None, logger=None, verbose=True):
    if dictContains(data, "date_limit") and dateLimit is None:
        dateLimit = data["date_limit"]
    if dictContains(data, "scrap"):
        scrap = data["scrap"]
    else:
        scrap = data
    if dateLimit is None or oldTweetsMax is None:
        logError("Please set dataLimit and oldTweetsMax.", logger=logger, verbose=verbose)
        return False
    if isinstance(dateLimit, str):
        dateLimit = dateToTimestamp(dateLimit)
    oldTweetsCount = 0
    if dictContains(scrap, "tweets"):
        for tweet in scrap["tweets"]:
            if dictContains(tweet, "timestamp"):
                if tweet["timestamp"] < dateLimit:
                    oldTweetsCount += 1
                else:
                    oldTweetsCount = 0 # To have consecutive old tweets
                if oldTweetsCount >= oldTweetsMax:
                    return True
    return False

# def getTweetTextLanguage(tweetText, logger=None, verbose=True):
#     # We first remove all urls, @ and #:
#     text = cleanTweetText(tweetText, logger=logger, verbose=True)
#     return recognize(text, logger=logger, verbose=True)



# def isEnUser(row, *args, minRatio=0.6, **kwargs):
#     enRatio = getUserEnRatio(row, *args, **kwargs)
#     if enRatio >= minRatio:
#         return True
#     else:
#         return False












