from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from hjwebbrowser.utils import *
from databasetools.mongo import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *
from twittercrawler.utils import *
from datastructuretools.processing import *
from multiprocessing import Pool as MPPool
from bs4 import BeautifulSoup


html5 = \
"""
<!DOCTYPE html>
<html>
    <head>
        <title>HTML5</title>
        <meta charset="UTF-8"/>
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="./css/style.css"/>
    </head>
    <body>

        <script src="./javascript/test.js"></script>
    </body>
</html>
"""



def openChrome():
    b = Browser(useFastError404Detection=True, proxy=getRandomProxy(),
                    driverType=DRIVER_TYPE.chrome)
    time.sleep(1000000)

def scrapTest():
    obama = "https://twitter.com/BarackObama"
    lambdaUser = "https://twitter.com/Anand_Gopal_"
    b = Browser(useFastError404Detection=True, proxy=getRandomProxy(),
                    driverType=DRIVER_TYPE.chrome)
    ts = TwitterScraper()
    for url in [obama, lambdaUser]:
        b.get(url)
        printLTS(reduceUserCrawlRow(ts.scrapUser(b), deleteTweets=True))



if __name__ == '__main__':
#     openChrome()
    scrapTest()


















