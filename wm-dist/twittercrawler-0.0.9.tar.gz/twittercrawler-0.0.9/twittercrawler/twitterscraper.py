from systemtools.basics import *
from systemtools.logger import *
from systemtools.file import *
from systemtools.location import *
from hjwebbrowser.browser import *
from hjwebbrowser.httpbrowser import *
from hjwebbrowser.utils import *
from scroller.scroller import *
from honeypotdetector.detector import *
from bs4 import BeautifulSoup
from scroller.scroller import *
from twittercrawler import __version__
import time
import datetime
from nlptools.langrecognizer import *
from twittercrawler.utils import *
from twittercrawler.hoveruser import *
from databasetools.mongo import *


TWEET_TYPE = Enum("TWEET_TYPE", "tweet retweet rtcomment reply")
PAGE_TYPE = Enum("PAGE_TYPE", "user search unknown")
class TwitterScraper:
    """
        This class is not intended to be used in parallel.
        So pls instanciate TwitterScrapers for each selenium driver.
    """
    def __init__(self,
                    logger=None,
                    verbose=True,
                    dateLimit=None,
                    oldTweetsMax=10,
                    sleepSignalDuration=3,
                    stopSignalCountMax=3,
                    name=None,
                    defaultMaxHoverCandidatesPerPage=5,
                    test=False):
        self.test = test
        self.defaultMaxHoverCandidatesPerPage = defaultMaxHoverCandidatesPerPage
        self.logger = logger
        self.verbose = verbose
        self.name = name
        if self.name is None:
            self.name = getRandomName()

        self.langRecognizer = LangRecognizer(logger=self.logger,
                                             verbose=self.verbose)

        self.sleepSignalDuration = sleepSignalDuration
        self.oldTweetsMax = oldTweetsMax
        self.stopSignalCountMax = stopSignalCountMax

        self.setDateLimite(dateLimit)

        self.tweetCache = SerializableDict(funct=self.parseTweet,
                                           limit=10000,
                                           logger=self.logger,
                                           verbose=self.verbose,
                                           raiseBadDesignException=True,
                                           cacheCheckRatio=0.01,)
        self.profilCardCache = SerializableDict(funct=self.parseProfilCard,
                                                limit=1000,
                                               logger=self.logger,
                                               verbose=self.verbose,
                                               raiseBadDesignException=True,
                                               cacheCheckRatio=0.01,)
        self.profilNavCache = SerializableDict(funct=self.parseProfilNav,
                                               limit=1000,
                                               logger=self.logger,
                                               verbose=self.verbose,
                                               raiseBadDesignException=True,
                                               cacheCheckRatio=0.01,)
        self.urlParser = URLParser(logger=self.logger, verbose=self.verbose)
        self.twitterUrl = "https://twitter.com"

        # self.honeypotDetector.isHoneypot(atreply["url"], driver)


#         self.honeypotDetector = HoneypotDetector(logger=self.logger, verbose=self.verbose)
#         self.honeypotDetectorCache = SerializableDict(funct=self.honeypotDetector.isHoneypot,
#                                                limit=10000,
#                                                logger=self.logger,
#                                                verbose=self.verbose,
#                                                raiseBadDesignException=False,)

        self.hus = None


    def setDateLimite(self, dateLimit):
        self.dateLimit = dateLimit
        if self.dateLimit is None:
            self.dateLimit = "01/11/2017"
        if isinstance(self.dateLimit, str):
            self.dateLimitStr = self.dateLimit
            self.dateLimit = dateToTimestamp(self.dateLimit)

    def initHus(self):
        if self.hus is None:
            if self.test:
                self.hus = HoverUserScroller(mongoUser=None, mongoHostname="localhost",
                                             logger=self.logger, verbose=self.verbose)
            else:
                self.hus = HoverUserScroller(logger=self.logger, verbose=self.verbose)

    def userStopFunct(self,
                      driver,
                      totalDistance=0,
                      minScrollTopReached=None,
                      maxScrollBottomReached=None):
        try:
#             print("userStopFunct launched !!!!")
            # We first get some infos:
            (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
            userData = self.scrapUser(driver)
            # We check if tweets changed:
#             print("self.previousTweetsLen: " + str(self.previousTweetsLen))
            tweetsChanged = False
            if dictContains(userData, "tweets"):
                tweetsLen = len(userData["tweets"])
#                 print("tweetsLen: " + str(tweetsLen))
                if self.previousTweetsLen != tweetsLen:
                    tweetsChanged = True
                self.previousTweetsLen = tweetsLen
            # We check if max scroll bottom reached changed:
            maxScrollBottomReachedChanged = False
#             print("self.previousMaxScrollBottomReached: " + str(self.previousMaxScrollBottomReached))
#             print("maxScrollBottomReached: " + str(maxScrollBottomReached))
            if self.previousMaxScrollBottomReached != maxScrollBottomReached:
                maxScrollBottomReachedChanged = True
                self.previousMaxScrollBottomReached = maxScrollBottomReached
            # We check if the document height changed:
#             print("self.previousDocumentHeight: " + str(self.previousDocumentHeight))
#             print("documentHeight: " + str(documentHeight))
            documentHeightChanged = False
            if self.previousDocumentHeight != documentHeight:
                documentHeightChanged = True
                self.previousDocumentHeight = documentHeight
            # We check if we got enough too old tweets:
            hasEnoughTooOldTweets = userData["has_enough_old_tweets"]
            # We check if we have to stop (all previous booleans):
            if (not tweetsChanged and not documentHeightChanged and not maxScrollBottomReachedChanged) or hasEnoughTooOldTweets:
                messageStart = "TwitterScraper scrolling of " + self.name + " for " + str(userData["url"]) + ": "
                if not tweetsChanged and not documentHeightChanged and not maxScrollBottomReachedChanged:
                    log(messageStart + "Nothing changed.", self)
                elif hasEnoughTooOldTweets:
                    log(messageStart + "We have enough old tweets.", self)
                if hasEnoughTooOldTweets:
                    log(messageStart + "We can stop the scroll.", self)
                    return True
                else:
                    # And if we want to try an other time:
                    if self.stopSignalCount < self.stopSignalCountMax:
                        log(messageStart + "Now we sleep and retry...", self)
                        self.stopSignalCount += 1
                        randomSleep(self.sleepSignalDuration, self.sleepSignalDuration + self.sleepSignalDuration * 0.3)
                        return False
                    else:
                        log(messageStart + "We can stop the scroll.", self)
                        return True
            else:
                return False
        except Exception as e:
            logException(e, self, location="TwitterScraper userStopFunct")
            return True

# Old recusive call:
#                     # We randomly sleep:
#                     randomSleep(randomSleepAmount, randomSleepAmount + randomSleepAmount * 0.3)
#                     # And we retry the stop funct which will return True if it not detect
#                     # any change after stopSignalCountMax retries
#                     # Or will return False if it get a change:
#                     return self.userStopFunct(driver,
#                                          totalDistance=totalDistance,
#                                          stopSignalCount=stopSignalCount+1,
#                                          stopSignalCountMax=stopSignalCountMax,
#                                          randomSleepAmount=randomSleepAmount,
#                                          minScrollTopReached=minScrollTopReached,
#                                          maxScrollBottomReached=maxScrollBottomReached)

    def scrollUserPage(self, driver, stopFunct=None, hoverUserScrollParams={}):
        """
            If you want to set the date limit, pls use the constructor or set it directly
        """
        (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
        self.stopSignalCount = 0
        self.previousTweetsLen = -1
        self.previousDocumentHeight = documentHeight
        self.previousMaxScrollBottomReached = scrollBottom
        if stopFunct is None:
            stopFunct = self.userStopFunct
        userData = self.scrapUser(driver)
        maxHoverCandidatesPerPage = self.defaultMaxHoverCandidatesPerPage
        if crawlingCandidateScore(userData, self, test=self.test) == 0.0:
            maxHoverCandidatesPerPage = 0
        if maxHoverCandidatesPerPage == 0:
            log("User " + str(userData["url"]) + " is not allowed to scrap hover users.", self)
        self.initHus()
        hoverUsersData = self.hus.scroll(driver,
                                         stopFunct=stopFunct,
                                         source=userData["user_id"],
                                         sourceType=PAGE_TYPE.user,
                                         maxHoverCandidatesPerPage=maxHoverCandidatesPerPage,
                                         **hoverUserScrollParams)
        return hoverUsersData

#     def scrollUserPage_old(self, driver, stopFunct=None):
#         """
#             If you want to set the date limit, pls use the contructor or set it directly
#         """
#         (scrollTop, scrollBottom, windowHeight, documentHeight) = getPageInfos(driver)
#         self.stopSignalCount = 0
#         self.previousTweetsLen = -1
#         self.previousDocumentHeight = documentHeight
#         self.previousMaxScrollBottomReached = scrollBottom
#         if stopFunct is None:
#             stopFunct = self.userStopFunct
#         scroll(driver, stopFunct=stopFunct, stopAtBottom=False)



    def getAtrepliesCandidates(self, driver, atrepliesFilter=None, maxAtreplies=100):
        candidates = []
        try:
            userData = self.scrapUser(driver)
            for tweet in userData["tweets"]:
                for atreply in tweet["atreplies"]:
                    if len(candidates) >= maxAtreplies:
                        return candidates
                    alreadyIn = False
                    for current in candidates:
                        if current["url"] == atreply["url"]:
                            alreadyIn = True
                    if not alreadyIn:
                        if atrepliesFilter is None or atrepliesFilter(atreply):
                            if not self.honeypotDetectorCache.get(atreply["url"], driver):
                                candidates.append(atreply)
            return candidates
        except Exception as e:
            logException(e, self, location="TwitterScraper getAtrepliesCandidates")
            return candidates

    def getHtmlAndDriver(self, htmlOrDriver, url=None):
        html = None
        driver = None
        url = None
        if isinstance(htmlOrDriver, str):
            html = htmlOrDriver
        else:
            driver = htmlOrDriver
            try:
                html = driver.page_source
                url = driver.current_url
            except Exception as e:
                logException(e, self, location="TwitterScraper parse method.")
                return None
        return (html, url, driver)

    def getPageType(self, htmlOrDriver, url=None):
        (html, url, driver) = self.getHtmlAndDriver(htmlOrDriver, url=url)
        userData = self.scrapUser(htmlOrDriver, url=url)
        # TODO enhance this:
        if \
            dictContains(userData, "avatar") and \
            dictContains(userData, "name") and \
            dictContains(userData, "username") and \
            dictContains(userData, "tweets") and \
            len(userData["tweets"]) > 0 and \
            dictContains(userData, "tweet_count") and \
        True:
            return PAGE_TYPE.user
        else:
            return PAGE_TYPE.unknown

    def getEnRatio(self, row):
        """
            This function return a ratio which is the ratio of clearly identified tweets as english
        """
        try:
            enCount = 0
            total = 0
            tweets = []
            if "scrap" in row:
                tweets = row["scrap"]["tweets"]
            else:
                tweets = row["tweets"]
            for current in tweets:
                text = current["text"]
                if text is not None and len(text) > 2:
                    text = cleanTweetText(text)
                    lang = self.langRecognizer.recognize(text)
                    if lang is None or lang == "":
                        pass
                    elif lang == "en":
                        enCount += 1
                        total += 1
                    else:
                        total += 1
            if total == 0:
                return 0.0
            else:
                return float(enCount) / float(total)
        except Exception as e:
            logException(e, self, location="getUserEnRatio()")
            return 0.0

    def scrapUser(self, htmlOrDriver, url=None, hoverUsersData=None):
        """
            The best choice is to give a driver so the class can check honeypots
        """
        if isinstance(htmlOrDriver, Browser):
            htmlOrDriver = htmlOrDriver.driver
        (html, url, driver) = self.getHtmlAndDriver(htmlOrDriver, url=url)
        # For test purpose:
        if url is not None and url.startswith("file://"):
            url = url.replace("file://", "http://localhost.com")
        # We get the soup:
        soup = BeautifulSoup(html, 'html.parser')
        # We try to find the profil card:
        profilCardSoup = soup.select_one("div.AppContainer div.ProfileSidebar")
        profilCardData = None
        if profilCardSoup is not None:
            profilCardData = self.profilCardCache.get(str(profilCardSoup), soup=profilCardSoup)
        # We try to get the avatar:
        avatarSoup = soup.select_one("img.ProfileAvatar-image")
        avatar = None
        if avatarSoup is not None and avatarSoup.has_attr("src"):
            src = avatarSoup["src"]
            avatar = {"avatar": self.urlParser.join(url, src)}
        # We try to get the profil nav:
        profilNavSoup = soup.select_one("div.ProfileNav")
        profilNavData = None
        if profilNavSoup is not None:
            profilNavData = self.profilNavCache.get(str(profilNavSoup), soup=profilNavSoup)
        userId = None
        if dictContains(profilNavData, "user_id"):
            userId = profilNavData["user_id"]
        # We parse all tweets:
        allTweetData = []
        for tweet in self.getAllTweets(htmlOrDriver):
            tweetData = self.tweetCache.get(str(tweet), soup=tweet, sourceType=PAGE_TYPE.user, source=userId)
            if tweetData is not None and len(tweetData) > 0 and tweetData["tweet_id"] is not None:
                # We have to clone the dict to ensure scrap_timestamp and scrap_version will not be stored in the cache which can cause a bad design exception...
                tweetData = dict(tweetData)
                allTweetData.append(tweetData)
        allTweetData = {"tweets": allTweetData}
        # We merge the result:
        result = mergeDicts(avatar, profilCardData, profilNavData, allTweetData) # allTweetData
        result["scrap_version"] = __version__
        result["tweets_en_ratio"] = self.getEnRatio(result)
        # Now we calculate if the user has enough old tweets:
        if self.dateLimit is not None:
            result["date_limit"] = self.dateLimitStr
            result["consecutive_old_tweets"] = self.oldTweetsMax
            result["has_enough_old_tweets"] = hasEnoughOldTweets \
            (
                result,
                dateLimit=self.dateLimit,
                oldTweetsMax=self.oldTweetsMax,
                logger=self.logger,
                verbose=self.verbose,
            )
        # Now we add hover users:
        if hoverUsersData is not None:
            result["hover_users"] = hoverUsersData
        # We get the url:
        url = None
        try:
            url = result["url"]
        except Exception as e:
            logException(e, self, location="url = result[\"url\"]")
        # Now we check if we find blocked:
        pageState = getPageState(soup, logger=self.logger, verbose=self.verbose)
        result["page_state"] = pageState
        if pageState != PAGE_STATE.hasMoreItems:
            log("The page state of "  + self.name + " for " + str(url) + " is " + str(pageState), self)
        return result


    def isEnUser(self, obj, url=None, minRatio=0.8):
        if not isinstance(obj, dict):
            obj = self.scrapUser(obj, url=url)
        if obj["tweets_en_ratio"] >= minRatio:
            return True
        else:
            return False


    def getAllTweets(self, htmlOrDriver):
        (html, url, driver) = self.getHtmlAndDriver(htmlOrDriver)
        soup = BeautifulSoup(html, 'html.parser')
#         for current in soup.select(".stream li.stream-item"):
#             strToTmpFile(str(current), ext="html")
#         exit()
        # TODO we got the profil card under .stream li.stream-item -> strange
        return soup.select(".stream li.stream-item") # it return [] if nothing exists

    def parseTweet(self, keyHtml, soup=None, source=None, sourceType=None):
        """
            # For a better scraping:
            # https://help.twitter.com/fr/using-twitter/types-of-tweets
            # https://developer.twitter.com/en/docs/tweets/data-dictionary/overview/tweet-object
        """
        data = {}
        # We get data:
        data["source_type"] = sourceType
        data["source"] = source
        data["scrap_version"] = __version__
        data["tweet_id"] = getSoupAttr(soup, "data-tweet-id", ".tweet")
        data["name"] = getSoupAttr(soup, "data-name", ".tweet")
        data["username"] = getSoupAttr(soup, "data-screen-name", ".tweet") # Or screenname
        data["permalink"] = self.urlParser.join(self.twitterUrl,
                                                getSoupAttr(soup, "data-permalink-path", ".tweet"))
        data["timestamp_ms"] = getFirstNumber(getSoupAttr(soup, "data-time-ms", ".tweet-timestamp span"))
        data["timestamp"] = getFirstNumber(getSoupAttr(soup, "data-time", ".tweet-timestamp span"))
        data["date"] = getSoupText(soup, ".tweet-timestamp span")
        data["lang"] = getSoupAttr(soup, "lang", ".tweet-text")
        data["text"] = getSoupText(soup, ".tweet-text")
        data["text_html"] = str(soup.select_one(".tweet-text"))
        data["container_text"] = getSoupText(soup, ".js-media-container")
        data["quote_text"] = getSoupText(soup, ".QuoteTweet")
        if data["quote_text"] == data["container_text"]:
            data["container_text"] = None
        # Now we get all links:
        data["hashtags"] = []
        data["atreplies"] = []
        data["shares"] = []
        data["pics"] = []
        for hashtagSoup in soup.select(".js-tweet-text-container .tweet-text .twitter-hashtag"):
            hashtagData = {}
            hashtagData["relative_url"] = getSoupAttr(hashtagSoup, "href")
            hashtagData["url"] = self.urlParser.join(self.twitterUrl, hashtagData["relative_url"])
            hashtagData["text"] = getSoupText(hashtagSoup)
            data["hashtags"].append(hashtagData)
        for atreplySoup in soup.select(".js-tweet-text-container .tweet-text .twitter-atreply"):
            atreplyData = {}
            atreplyData["user_id"] = getSoupAttr(atreplySoup, "data-mentioned-user-id")
            atreplyData["relative_url"] = getSoupAttr(atreplySoup, "href") # Necessary online (not offline)
            atreplyData["url"] = self.urlParser.join(self.twitterUrl, atreplyData["relative_url"])
            atreplyData["text"] = getSoupText(atreplySoup)
            data["atreplies"].append(atreplyData)
        for shareSoup in soup.select(".js-tweet-text-container .tweet-text .twitter-timeline-link"):
            # Can be a twitter quote, a twitter media, or a shared link:
            shareData = {}
            shareData["url"] = getSoupAttr(shareSoup, "title")
            shareData["url"] = self.urlParser.normalize(shareData["url"])
            if shareData["url"] is None:
                shareData["shortened_url"] = getSoupAttr(shareSoup, "href")
                shareData["url"] = "http://" + getSoupText(shareSoup)
                data["pics"].append(shareData)
            else:
                data["shares"].append(shareData)
        # Now we extract all quote in shares:
        data["quotes"] = []
        newShares = []
        for currentShare in data["shares"]:
            value = currentShare["url"]
            if value is not None and value.startswith("https://twitter"):
                data["quotes"].append(currentShare)
            else:
                newShares.append(currentShare)
        data["shares"] = newShares
        # Now we try to find the tweet type
        replySoup = soup.select_one(".ReplyingToContextBelowAuthor")
        context = getSoupText(soup, ".tweet-context")
        if replySoup is not None:
            data["type"] = TWEET_TYPE.reply.name
        elif context is not None and "retweet" in context.lower():
            data["type"] = TWEET_TYPE.retweet.name
        elif data["text"] is not None and "RT @" in data["text"]:
            data["type"] = TWEET_TYPE.rtcomment.name
        else:
            data["type"] = TWEET_TYPE.tweet.name
        # Now we get stats about the tweet:
        data["reply_count"] = getFirstNumber(getSoupAttr(soup, "data-tweet-stat-count", ".ProfileTweet-action--reply .ProfileTweet-actionCount"))
        data["retweet_count"] = getFirstNumber(getSoupAttr(soup, "data-tweet-stat-count", ".ProfileTweet-action--retweet .ProfileTweet-actionCount"))
        data["like_count"] = getFirstNumber(getSoupAttr(soup, "data-tweet-stat-count", ".ProfileTweet-action--favorite .ProfileTweet-actionCount"))
        # And return all:
        return data

    def parseProfilCard(self, keyHtml, soup=None):
        data = {}
        data["location"] = getSoupText(soup, ".ProfileHeaderCard-locationText")
        data["bio"] = getSoupText(soup, ".ProfileHeaderCard-bio")
        data["name"] = getSoupText(soup, ".ProfileHeaderCard-nameLink")
        # div.AppContainer div.ProfileSidebar .username b
        data["username"] = getSoupText(soup, ".username b") # Or screenname
        data["url"] = self.urlParser.join(self.twitterUrl,
                        getSoupAttr(soup, "href", "a.ProfileHeaderCard-screennameLink"))
        data["user_website"] = getSoupAttr(soup, "title", ".ProfileHeaderCard-urlText a")
        data["user_twitter_website"] = getSoupAttr(soup, "href", ".ProfileHeaderCard-urlText a")
        data["joindate_title"] = getSoupAttr(soup, "title", ".ProfileHeaderCard-joinDate .ProfileHeaderCard-joinDateText") # or data-original-title
        data["joindate_text"] = getSoupText(soup, ".ProfileHeaderCard-joinDate .ProfileHeaderCard-joinDateText")
        if data["joindate_text"] is not None:
            data["joindate_text"] = data["joindate_text"].replace("Joined", "").strip()
        data["media_count"] = getFirstNumber(getSoupText(soup, ".PhotoRail-headingWithCount"), removeCommas=True)
        data["verified"] = None
        if soup is not None:
            data["verified"] = soup.select_one(".ProfileHeaderCard-name .Icon--verified") is not None
        return data


    def parseProfilNav(self, keyHtml, soup=None):
        data = {}
        for (name, selector) in \
        [
            ("tweet_count", ".ProfileNav-item--tweets"),
            ("following_count", ".ProfileNav-item--following"),
            ("follower_count", ".ProfileNav-item--followers"),
            ("favorite_count", ".ProfileNav-item--favorites"),
            ("list_count", ".ProfileNav-item--lists"),
            ("moment_count", ".ProfileNav-item--moments"),
        ]:
            selector += " .ProfileNav-value"
            if getSoupAttr(soup, "data-is-compact", selector) == "false":
                text = getSoupText(soup, selector)
                data[name] = getFirstNumber(text, removeCommas=True)
            else:
                text = getSoupAttr(soup, "data-count", selector)
                data[name] = getFirstNumber(text)
        data["user_id"] = getSoupAttr(soup, "data-user-id")
        return data






def test1():
    """
        Pour le test : 3 élements avant le 24 décembre stop le scraping
    """
    proxies = getProxiesRenew()
    proxy = proxies[0]
    b = Browser(proxy=proxy, driverType=DRIVER_TYPE.chrome, headless=False, useFastError404Detection=True)
    # b = Browser(proxy=None, driverType=DRIVER_TYPE.chrome, headless=False)
    b.setWindowSize(1600, 600)
    b.setWindowPosition(5, 500)
    datatestFiles = sortedGlob("/home/hayj/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/*reduced*.html")
#     datatestFiles = sortedGlob("/home/hayj/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/*.html")
    b.html("file://" + datatestFiles[0])
    # b.html("https://twitter.com/sturdyAlex")
#     scroll(b, distance=20000, stopAtBottom=True)
    tus = TwitterScraper \
    (
        dateLimit="24/12/2017",
        oldTweetsMax=3,
        stopSignalCountMax=1,
        sleepSignalDuration=3,
    )
    print("page type = " + str(tus.getPageType(b.driver)))
    printLTS(tus.scrapUser(b.driver))
    tus.scrollUserPage(b.driver, fastScroll=False)
#     for i in range(10):
#         randomSleep(2, 3)
#         printLTS(tus.getAtrepliesCandidates(b.driver))
    printLTS(tus.getAtrepliesCandidates(b.driver))
    # printLTS(tus.getAllTweets(b.driver))
#     printLTS(tus.scrapUser(b.driver))
    print("DONE")
    time.sleep(10000)
    # b.checkProxy()
    b.close()

def test2():
    pass



# from newscrawler.twitteruser import *
def rtcommentTest():
    tu = TwitterUser("7613582")
    html = tu.getHtml()
    tus = TwitterScraper()
    userData = tus.scrapUser(html)
    userDataToReadableTmpFile(userData)
def replyTest():
    tu = TwitterUser("3807879852")
    html = tu.getHtml()
    tus = TwitterScraper()
    userData = tus.scrapUser(html)
    userDataToReadableTmpFile(userData)


if __name__ == '__main__':
    print("START")
#     test1()
#     test2()
    rtcommentTest()
#     replyTest()



# b.checkProxy()

# b.html("https://twitter.com/milliebbrown")

# b.html("https://www.whatismybrowser.com/detect/what-http-headers-is-my-browser-sending")
# b.html("https://whatismyipaddress.com/fr/mon-ip")

# randomSleep(100, 1000)


# datatestFiles = sortedGlob("/home/hayj/Workspace/Python/Datasets/TwitterCrawler/twittercrawler/datatest/*.html")
# for current in datatestFiles[:] + ["/home/hayj/Workspace/Python/Crawling/HoneypotDetector/honeypotdetector/test.html"]:
#     b.html("file://" + current)
#     # scroll(b, distance=200, stopAtBottom=True)
#     tus = TwitterScraper()
#     print("page type = " + str(tus.getPageType(b.driver)))
#     printLTS(tus.scrapUser(b.driver))

# exit()

# b.html("https://www.whatismybrowser.com/detect/what-http-headers-is-my-browser-sending")
# b.html("https://twitter.com/strangerrpolls?lang=en-US")
# b.html("https://twitter.com/milliebbrown")
# b.html("https://twitter.com/timjenki")
# b.html("https://twitter.com/shelleyreal")
# b.html("https://twitter.com/sturdyAlex")
# b.html("file:///home/hayj/Drive/Workspace/Python/Crawling/Scroller/scroller/scroll.html")






# time.sleep(1000)
#
# b.close()
