from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from collections import OrderedDict
from twittercrawler.hoveruser import *
from twittercrawler.utils import *
import sh


def setWindowSize(d, x, y):
    d.set_window_size(x, y)
def setWindowPosition(d, x, y):
    d.set_window_position(x, y)

def test1():
    driver = webdriver.Chrome()

    driver.get("http://www.flipkart.com/watches/pr?p%5B%5D=facets.ideal_for%255B%255D%3DMen&p%5B%5D=sort%3Dpopularity&sid=r18&facetOrder%5B%5D=ideal_for&otracker=ch_vn_watches_men_nav_catergorylinks_0_AllBrands")

    setWindowSize(driver, 1600, 1000)
    setWindowPosition(driver, 5, 500)

    # wait for Men menu to appear, then hover it
    men_menu = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, ".sYph0c")))
    ActionChains(driver).move_to_element(men_menu).perform()

    # wait for Fastrack menu item to appear, then click it
    fastrack = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, "//a[@data-tracking-id='0_Fastrack']")))
    fastrack.click()


def seleniumWaitUntil(driver, cssSelector, timeout=10):
    try:
        WebDriverWait(driver, timeout).until(EC.visibility_of_element_located((By.CSS_SELECTOR, cssSelector)))
        return True
    except:
        return False

def test2():
    driver = webdriver.Chrome()

    driver.get("http://stackoverflow.com/tags")

    setWindowSize(driver, 1600, 1000)
    setWindowPosition(driver, 5, 500)

    assert not seleniumWaitUntil(driver, "#tag-menu", timeout=3)


    for i in range(10):
        time.sleep(5)
        tags = driver.find_elements_by_css_selector(".post-tag[href=\"/questions/tagged/java\"]")

        action = webdriver.ActionChains(driver)
        action.move_to_element(tags[0])
        action.perform()

        assert seleniumWaitUntil(driver, "#tag-menu", timeout=3)

        try:
            element = driver.find_element_by_css_selector("#tag-menu")
            if element is not None:
                print(element)
            else:
                print("no element")
        except:
            print("FU")


    time.sleep(1000)

def test3():
    driver = webdriver.Chrome()

    setWindowSize(driver, 1600, 600)
    setWindowPosition(driver, 5, 500)

    driver.get("http://stackoverflow.com/tags")


    assert not seleniumWaitUntil(driver, "#tag-menu", timeout=3)


    for i in range(10):
        time.sleep(5)
        tags = driver.find_elements_by_css_selector(".post-tag[href=\"/questions/tagged/wpf\"]")

        action = webdriver.ActionChains(driver)
        action.move_to_element(tags[0])
        action.perform()

        if seleniumWaitUntil(driver, "#tag-menu", timeout=3):
            element = driver.find_element_by_css_selector("#tag-menu")
            if element is not None:
                print(element)
            else:
                print("no element")


    time.sleep(1000)





def test4():
    startUrl = "https://twitter.com/sturdyAlex"
#     startUrl = "https://twitter.com/Twitter"


    proxy = getProxiesRenew()[0]
    b = Browser(driverType=DRIVER_TYPE.chrome, proxy=proxy)

    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)

    b.html(startUrl)

    printLTS(getAllHoverSources(b.driver, reverse=False))





    randomSleep(1000)



    b.close()




def htmlCallback(data, browser=None):
    allAtreplies = browser.driver.find_elements_by_css_selector("a.twitter-atreply.pretty-link.js-nav")
    men_menu = WebDriverWait(browser.driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, "a.twitter-atreply.pretty-link.js-nav")))
    ActionChains(browser.driver).move_to_element(men_menu).perform()
    for current in allAtreplies:
        print(current)

def test5():
    startUrl = "https://twitter.com/sturdyAlex"
#     startUrl = "https://twitter.com/Twitter"


    proxy = getProxiesRenew()[0]
    b = Browser(driverType=DRIVER_TYPE.phantomjs, proxy=proxy, useFastError404Detection=True)

    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)

    b.html(startUrl)


#     script = \
#     """
#         scroll()
#         function scroll()
#         {
#             window.scrollTo(0, window.scrollY + 50);
#             setTimeout(scroll, 0.001 * 1000);
#         }
#     """
#
#     b.driver.execute_script(script)

#     for i in range(1000000):
#         executeScroll(b.driver, 50)
#         time.sleep(0.001)


    scroll(b.driver, stopAtBottom=False)




    randomSleep(1000)



    b.close()


def test6():
    proxy = getProxiesRenew()[0]
    b = Browser(driverType=DRIVER_TYPE.chrome, proxy=proxy, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    dateLimit = "02/02/2018"
    startUrl = "https://twitter.com/sturdyAlex"
    tus = TwitterScraper(dateLimit=dateLimit)
    b.get(startUrl)
    tus.scrollUserPage(b.driver)

    print(getAllHoverSources(b.driver, reverse=True))

#     userData = tus.scrapUser(b.driver, handleHoverUsers=True)
#     strToFile(listToStr(userData), tmpDir() + "/test.txt")


    randomSleep(1000)
    b.close()


def test8():
    proxy = getProxiesTest()[0]
    b = Browser(driverType=DRIVER_TYPE.chrome, proxy=None, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    startUrl = "https://twitter.com/sturdyAlex"
    b.get(startUrl)
    hus = HoverUserScroller(mongoUser=None, mongoHostname="localhost")
    hus.hoverUserCollection.resetCollection()
    printLTS(hus.scroll(b.driver))


    randomSleep(1000)
    b.close()

def test9():
    proxy = getProxiesTest()[0]
    b = Browser(driverType=DRIVER_TYPE.phantomjs, proxy=None, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    startUrl = "https://twitter.com/sturdyAlex"
    b.get(startUrl)
    hus = HoverUserScroller(mongoUser=None, mongoHostname="localhost")
    hus.hoverUserCollection.show(10)
    exit()
    hus.hoverUserCollection.resetCollection()
    strToTmpFile(listToStr(hus.scroll(b.driver, distance=10000)))


    randomSleep(1000)
    b.close()


def test10():
    proxy = getProxiesTest()[0]
    b = Browser(driverType=DRIVER_TYPE.chrome, proxy=None, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    tus = TwitterScraper(test=True, dateLimit="15/02/2016", oldTweetsMax=3, name=b.name)
    tus.hus.hoverUserCollection.show(10)
    input("Continue ?")
    tus.hus.hoverUserCollection.resetCollection()
    for current in \
    [
#         "https://twitter.com/sturdyAlex",
        "file:///home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/alex_profile_reduced.html",
    ]:
        b.get(current)
        if "file://" in current:
            waitForHoverDuration = 0.5
        else:
            waitForHoverDuration = 2.0
        hoverUsersData = tus.scrollUserPage(b.driver, hoverUserScrollParams={"waitForHoverDuration": waitForHoverDuration})
        userData = tus.scrapUser(b.driver, hoverUsersData=hoverUsersData)
        userDataReduced = reduceDictStr(userData, reduceLists=True, replaceNewLine=True)
        print(strToTmpFile(listToStr(userDataReduced)))


#     randomSleep(1000)
    b.close()

def blockedStoppedTest():
    print("DEPRECATED")
    proxy = getProxiesTest()[0]
    b = Browser(pageLoadTimeout=100, driverType=DRIVER_TYPE.chrome, proxy=proxy, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    tus = TwitterScraper(test=True, dateLimit="15/02/2016", oldTweetsMax=3, name=b.name)
#     tus.hus.hoverUserCollection.resetCollection()
    for (url, blocked, stopped) in \
    [
        ("https://twitter.com/sturdyAlex", False, False),
        ("file:///home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/not_blocked_not_stopped.html", False, False),
        ("file:///home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/reduced_back_to_top.html", False, True),
        ("file:///home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/alex_profile_reduced.html", True, False),
    ]:
        b.get(url)
        userData = tus.scrapUser(b.driver)
        if userData["blocked"]:
            print(url[0:20] + "... is blocked!")
        else:
            print(url[0:20] + "... is NOT blocked!")
        if userData["stopped"]:
            print(url[0:20] + "... is stopped!")
        else:
            print(url[0:20] + "... is NOT stopped!")
        assert userData["blocked"] == blocked
        assert userData["stopped"] == stopped
#         print(url + " --> " + strToTmpFile(listToStr(userData), ext="html"))
    b.close()

def blockedStoppedTest2():
    print("DEPRECATED")
    proxy = getProxiesTest()[0]
    b = Browser(pageLoadTimeout=100, driverType=DRIVER_TYPE.chrome, proxy=proxy, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    tus = TwitterScraper(test=True, dateLimit="15/02/2016", oldTweetsMax=3, name=b.name, verbose=False)
    for (url, blocked, stopped) in \
    [
#         ("file:///home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/twitter_page_avec_loading.html", False, False),
        ("https://twitter.com/twitter", False, False),
        ("https://twitter.com/twitter", True, False),
        ("https://twitter.com/familiesvalued", False, True),

    ]:
        # Attention pour le premier lien, il y a un fail sur le html (quand on utilise une mauvaise connexion (3g)) car il voit l'icon de loading et prends ça comme un blocked
        # voir fichier twitter_page_avec_loading
        fail = "============> FAILED <============="
        b.get(url)
        if blocked:
            smartScroll(b, distance=100000, stopAtBorder=True, timeout=5)
            disableWifi()
            smartScroll(b, distance=100000, stopAtBorder=True, timeout=5)
            time.sleep(5)
        elif stopped:
            smartScroll(b, distance=1000000, stopAtBorder=False, timeout=5)
        else:
            smartScroll(b, distance=10000, stopAtBorder=True, timeout=5)
        for current in [b.driver, b.driver.page_source]:
            if isinstance(current, str):
                print("Checking for the html...")
                print("--> " + strToTmpFile(current, ext="html"))
            else:
                print("Checking for the driver...")
            userData = tus.scrapUser(current)
            if userData["blocked"] == blocked:
                print("OK blocked=" + str(userData["blocked"]) + " " + url)
            else:
                print(fail)
                print("NOT OK blocked=" + str(userData["blocked"]) + " " + url)
            if userData["stopped"] == stopped:
                print("OK stopped=" + str(userData["stopped"]) + " " + url)
            else:
                print(fail)
                print("NOT OK stopped=" + str(userData["stopped"]) + " " + url)
        if blocked:
            enableWifi()
    b.close()


def blockedStoppedTest3():
    proxy = getProxiesTest()[0]
    b = Browser(pageLoadTimeout=100, driverType=DRIVER_TYPE.chrome, proxy=proxy, useFastError404Detection=True)
    b.setWindowSize(1600, 1000)
    b.setWindowPosition(5, 500)
    tus = TwitterScraper(test=True, dateLimit="15/02/2016", oldTweetsMax=3, name=b.name, verbose=False)
    for (url, pageState) in \
    [
        ("https://twitter.com/twitter", PAGE_STATE.hasMoreItems),
        ("https://twitter.com/twitter", PAGE_STATE.loading),
        ("https://twitter.com/twitter", PAGE_STATE.blocked),
        ("https://twitter.com/familiesvalued", PAGE_STATE.backToTop),

    ]:
        # Attention pour le premier lien, il y a un fail sur le html (quand on utilise une mauvaise connexion (3g)) car il voit l'icon de loading et prends ça comme un blocked
        # voir fichier twitter_page_avec_loading
        fail = "============> FAILED <============="
        b.get(url)
        if pageState == PAGE_STATE.blocked:
            smartScroll(b, distance=100000, stopAtBorder=True, timeout=5)
            disableWifi()
            smartScroll(b, distance=100000, stopAtBorder=True, timeout=5)
            time.sleep(5)
        elif pageState == PAGE_STATE.hasMoreItems:
            smartScroll(b, distance=10000, stopAtBorder=True, timeout=5)
            time.sleep(5)
        elif pageState == PAGE_STATE.backToTop:
            smartScroll(b, distance=1000000, stopAtBorder=False, timeout=5)
        else:
            smartScroll(b, distance=10000, stopAtBorder=True, timeout=5)
        for current in [b.driver, b.driver.page_source]:
            if isinstance(current, str):
                print("Checking for the html...")
            else:
                print("Checking for the driver...")
            userData = tus.scrapUser(current)
            if userData["page_state"] != pageState:
                print(fail)
            print(str(userData["page_state"]) + " for " + url)
        if pageState == PAGE_STATE.blocked:
            enableWifi()
    b.close()

from bs4 import BeautifulSoup
def getPageStateTest():
    for current in sortedGlob("/home/hayj/Drive/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/page-states/*"):
        html = fileToStr(current)
        soup = BeautifulSoup(html, 'html.parser')
        print(current.split("/")[-1])
        print(getPageState(soup))
        print()
def getPageStateTest2():
    (user, password, host) = getMongoAuth()
    collection = MongoCollection \
    (
        "test",
        "usercrawl",
        user=user, host=host, password=password,
    )
    for current in collection.find():
        html = current["html"]
        soup = BeautifulSoup(html, 'html.parser')
        print(getPageState(soup))

def hasEnoughOldTweetsTest():
    (user, password, host) = getMongoAuth()
    collection = MongoCollection \
    (
        "test",
        "usercrawl",
        user=user, host=host, password=password,
    )
    i = 0
    for current in collection.find():
        print(hasEnoughOldTweets(current, oldTweetsMax=10, dateLimit="20/11/2017"))
        printLTS(reduceUserCrawlRow(current, deleteTweets=True))
        if i > 100:
            break
        i += 1

def indexTest():
    (user, password, host) = getMongoAuth()
    collection = MongoCollection \
    (
        "test",
        "usercrawl",
        user=user, host=host, password=password,
        indexNotUniqueOn=\
        [
            "scrap.page_state",
            "scrap.has_enough_old_tweets",
            "date_limit",
            "version",
            "hostname",
        ],
        indexOn=["user_id", "url"],
    )

if __name__ == '__main__':
    indexTest()





