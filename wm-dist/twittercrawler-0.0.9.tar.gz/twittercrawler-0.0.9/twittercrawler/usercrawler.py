# coding: utf-8

# nn pew in twittercrawler-venv python ~/wm-dist-tmp/TwitterCrawler/twittercrawler/usercrawler.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from twittercrawler import __version__
import pymongo
from twittercrawler.twitterscraper import *
from twittercrawler.hoveruser import *
from machinelearning.function import *


def getHoverStartUrls_old(collection, maxStartUrls=30, maxUserQueried=100):
    startUrls = []
    tus = TwitterScraper(test=TEST)
    allUsers = list(collection.find(sort=("timestamp", pymongo.DESCENDING), limit=maxUserQueried))
    for userData in allUsers:
        userData = userData["scrap"]
        startUrls += getHoverCandidates(userData, tus, collection=collection)
        if len(startUrls) > maxStartUrls:
            break
    random.shuffle(startUrls)
    return startUrls


def getHoverStartUrls(collection, maxStartUrls=50, takeProbability=0.1, logger=None, verbose=True):
    startUrls = []
    tus = TwitterScraper(test=TEST)
    for userData in collection.find():
        if getRandomFloat() < takeProbability:
            userData = userData["scrap"]
            startUrls += getHoverCandidates(userData, tus, collection=collection, logger=logger, verbose=verbose)
            if len(startUrls) > maxStartUrls:
                break
    random.shuffle(startUrls)
    return startUrls


def terminatedCallback(urlsFailedNotEnough, urlsFailedEnough):
    logInfo("urlsFailedNotEnough:", logger)
    logInfo(listToStr(urlsFailedNotEnough), logger)
    logInfo("urlsFailedEnough:", logger)
    logInfo(listToStr(urlsFailedEnough), logger)

def failedCallback(data):
    try:
        tmpFilePath = strToTmpFile(data["html"], name=getRandomStr(),
                                   subDir="usercrawl-fails", extension="html")
        data["html"] = "See the html content in " + tmpFilePath
        logError("This user failed:\n" + listToStr(data), logger)
    except Exception as e:
        logException(e, logger, location="failedCallback")


def atrepliesFilter(atreply):
    return not collection.has(atreply["user_id"])

def crawlingCallback(data, browser=None):
    # We got a new user profil page
    ce = data["crawlingElement"]
    del data["crawlingElement"]
    data["url"] = ce.data
    status = data["status"]
    if status in [REQUEST_STATUS.success, REQUEST_STATUS.error404, REQUEST_STATUS.timeoutWithContent]:
        data["status"] = REQUEST_STATUS.success
        try:
            # First we create the scraper:
            tus = TwitterScraper \
            (
                dateLimit=dateLimit,
                oldTweetsMax=oldTweetsMax,
                stopSignalCountMax=stopSignalCountMax,
                sleepSignalDuration=sleepSignalDuration,
                defaultMaxHoverCandidatesPerPage=defaultMaxHoverCandidatesPerPage,
                logger=logger,
                verbose=True,
                name=browser.name,
                test=TEST,
            )
            # We scroll and get data of the user:
            userData = tus.scrapUser(browser.driver)
            # We first check if it is a en user to continue:
            if tus.isEnUser(browser.driver):
                hoverUsersData = tus.scrollUserPage(browser.driver)
                data["html"] = browser.driver.page_source
                userData = tus.scrapUser(browser.driver, hoverUsersData=hoverUsersData)
                # We add the user to the data base:
                if userData["username"] is not None and userData["user_id"] is not None:
                    if not collection.has(userData["user_id"]):
                        data["user_id"] = userData["user_id"]
                        data["date_limit"] = dateLimit
                        data["scrap"] = userData
                        data["last_url"] = data["lastUrl"]
                        data["hostname"] = getHostname()
                        del data["lastUrl"]
                        data = camelCaseToUnderscoreCaseDict(data)
                        collection.insert(data)
                        try:
                            log("====> user " + data["scrap"]["username"] + " added to mongodb with " + str(len(data["scrap"]["tweets"])) + " tweets.", logger)
                        except Exception as e:
                            logException(e, logger, location="log(\"==> user \"...")
                    # We add hover candidates to the queue:
                    hoverCandidates = getHoverCandidates(userData, tus, collection=collection, maxHoverCandidates=20, logger=logger)
                    if len(hoverCandidates) == 0:
                        log("The user " + str(data["url"]) + " is NOT allowed to put any atreplies!", logger)
                    else:
                        log("Adding " + str(hoverCandidates[0]) + " and others to the crawler queue.", logger)
                    for candidate in hoverCandidates:
                        crawler.put(candidate)
        except Exception as e:
            logException(e, logger, location="crawlingCallback")


def getProxiesDist(proxies, hosts, hostsMaxDesc, default=20, logger=None, verbose=True):
    def getGlobalMax(currentAllMax):
        globalMax = 0
        for key, value in currentAllMax.items():
            globalMax += value
        return globalMax
    proxiesCount = len(proxies)
    # We compute all max:
    allMax = OrderedDict()
    for host in hosts:
        allMax[host] = None
        for startHost, theMax in hostsMaxDesc.items():
            if host.startswith(startHost):
                allMax[host] = theMax
                break
        if allMax[host] is None:
            logError(host + " not found in the desc.", logger)
            allMax[host] = default
    # We compute the max:
    globalMax = getGlobalMax(allMax)
    # Now we reduce if max are too much:
    if globalMax == proxiesCount:
        log("PERFECT, the max match the proxies len", logger)
    elif globalMax < proxiesCount:
        logError("We didn't use all proxies", logger)
    else:
        while getGlobalMax(allMax) > proxiesCount:
            for key, value in allMax.items():
                allMax[key] -= 1
                if getGlobalMax(allMax) <= proxiesCount:
                    break
    # We print max allocation:
    log("Proxies allocation:\n" + listToStr(allMax), logger)
    # Now we allocate all ips:
    proxiesAllocation = OrderedDict()
    currentProxiesIndex = 0
    for key, value in allMax.items():
        proxiesAllocation[key] = []
        for i in range(value):
            proxiesAllocation[key].append(proxies[currentProxiesIndex])
            currentProxiesIndex += 1
    return proxiesAllocation





if __name__ == '__main__':
    # TEST
    TEST = False
    if TEST and not isHostname("hjlat"):
        print("pls set TEST as False")
        exit()

    if TEST:
        random.seed(0)

    # Please set also isHoverUsercandidate default params for hover users scrap

    # Logger:
    if TEST or isHostname("hjlat"):
        logger = Logger("usercrawler.log", remove=True)
    else:
        logger = Logger("usercrawler-" + getHostname() + "-" + getRandomStr() + ".log", remove=False)
    log("Starting...", logger)

    # We set all proxies:
    if TEST:
        proxies = getProxiesTest()
    else:
        # We get all proxies:
        proxies = getAllProxies()
        # We get distributed hosts:
        hosts = ["datascience01", "tipi57", "tipi58", "tipi59", "tipi61", "tipi62", "tipi63",
                            "tipi56", "tipi93", "tipi94",
                            "tipi82", "tipi83", "tipi84", "tipi85", "tipi86", "tipi87",
                            "tipi88", "tipi89", "tipi90",
                            "hjmassy01"]
        # We get the proxies dist according to max:
        proxiesDist = getProxiesDist(proxies, hosts,
        {
            "tipi": 28, # 28
            "datascience": 30, # 30
            "hjmassy": 25, # 25

        }, logger=logger)
        if getHostname() in hosts:
            proxies = proxiesDist[getHostname()]
        if proxies is None:
            log("Host not set!", logger)
            exit()
    # All important params for the crawler:
    if TEST:
        browsersHeadless = False
        browserCount = parallelRequests = [1]
        driverType = DRIVER_TYPE.chrome # phantomjs, chrome
        banditRoundDuration = 30
        firstRequestSleepMin = 0.0
        firstRequestSleepMax = 5.0
        allRequestsSleepMin = 0.2
        allRequestsSleepMax = 0.9
        stopCrawlerAfterSeconds = 30
    else:
        browsersHeadless = True
        driverType = DRIVER_TYPE.phantomjs # phantomjs, chrome
        banditRoundDuration = 2000
        firstRequestSleepMin = 0.0
        firstRequestSleepMax = 200.0
        allRequestsSleepMin = 2.0
        allRequestsSleepMax = 15.0
        stopCrawlerAfterSeconds = 300
        if len(proxies) > 50:
            browserCount = parallelRequests = [getRAMTotal()]
        else:
            browserCount = parallelRequests = [len(proxies)]
    log("parallelRequests=" + str(parallelRequests[0]), logger)
    useProxies = True
    alpha = [0.99] # Pour avoir une instanciation de une fois tous les proxies
    pageLoadTimeout = 50
    maxRetryFailed = 3
    ajaxSleep = 4.0
    browserMaxDuplicatePerDomain = 3
    loadImages = True
    sameBrowsersParallelRequestsCount = True
    browserUseFastError404Detection = True

    # All important params for the scraper:
    if TEST:
        dateLimit = "12/02/2018" # 12/01/2018
        oldTweetsMax = 3
        stopSignalCountMax = 3
        sleepSignalDuration = 2
        defaultMaxHoverCandidatesPerPage = 1
    else:
        dateLimit = "01/11/2017" # 01/11/2017
        oldTweetsMax = 6
        stopSignalCountMax = 5
        sleepSignalDuration = 5
        defaultMaxHoverCandidatesPerPage = 10

    # Mongo collection init:
    if TEST:
        (user, password, host) = getMongoAuth(user=None, hostname="hjlat")
    else:
        (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    dbName = "twitter"
    collectionName = "usercrawl"
    if TEST or isHostname("hjlat"):
        dbName = "test"
    collection = MongoCollection \
    (
        dbName,
        collectionName,
        version=__version__,
        indexNotUniqueOn=\
        [
            "scrap.page_state",
            "scrap.has_enough_old_tweets",
            "date_limit",
            "version",
            "hostname",
        ],
        indexOn=["user_id", "url"],
        user=user, host=host, password=password,
        verbose=True,
        logger=logger,
        giveTimestamp=True,
    )
    collection.show(1, sort=("timestamp", pymongo.DESCENDING))
    collection.showDbs()
    if TEST and dbName == "test":
        collection.resetCollection()
        hoverUserCollection = MongoCollection("twitter", "hoverusers")
        hoverUserCollection.resetCollection()


    # We collect start urls:
    startUrls = getHoverStartUrls(collection, logger=logger)
    if startUrls is None or len(startUrls) == 0:
        startUrls = getStartUrls()
#     if TEST:
#         startUrls = [sortedGlob("/home/hayj/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/*reduced*.html")[0]]
#         startUrls += sortedGlob("/home/hayj/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/*.html")
#         for i in range(len(startUrls)):
#             startUrls[i] = "file://" + startUrls[i]
#         startUrls = ["https://twitter.com/sturdyAlex"]

    # We ask ready:
    if TEST:
#         startUrls = [sortedGlob("/home/hayj/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/datatest/*reduced*.html")[0]]
#         for i in range(len(startUrls)):
#             startUrls[i] = "file://" + startUrls[i]
        startUrls = ["https://twitter.com/mhenderson33"]
        printLTS(startUrls)
        input("Ready ?")

    # Now we delete all startUrls which are already in the database:
    if not TEST:
        newStartUrls = []
        for current in startUrls:
            if not collection.has({"url": current}):
                newStartUrls.append(current)
        startUrls = newStartUrls
    else:
        printLTS(startUrls)

    # We init the crawler:
    crawler = Crawler \
    (
        startUrls,
        paramsDomain = \
        {
            "proxyInstanciationRate":
            {
                "alpha": alpha,
                "beta": [NormalizedLawBeta.LOG]
            },
            "browserCount": browserCount,
            "parallelRequests": parallelRequests,
        },
        proxies=proxies,
        pageLoadTimeout=pageLoadTimeout, # 30
        failedCallback=failedCallback,
        crawlingCallback=crawlingCallback,
        terminatedCallback=terminatedCallback,
        browsersVerbose=True,
        banditRoundDuration=banditRoundDuration, # 500
        logger=logger,
        queueMinSize=50, # 300
        stopCrawlerAfterSeconds=stopCrawlerAfterSeconds,
        maxRetryFailed=maxRetryFailed,
        ajaxSleep=ajaxSleep,
        browserMaxDuplicatePerDomain=browserMaxDuplicatePerDomain,
        useProxies=useProxies,
        loadImages=loadImages,
        browsersHeadless=browsersHeadless,
        browsersDriverType=driverType,
        sameBrowsersParallelRequestsCount=sameBrowsersParallelRequestsCount,
        afterAjaxSleepCallback=None,
        beforeGetCallback=None,
        browserUseFastError404Detection=browserUseFastError404Detection,
        firstRequestSleepMin=firstRequestSleepMin,
        firstRequestSleepMax=firstRequestSleepMax,
        allRequestsSleepMin=allRequestsSleepMin,
        allRequestsSleepMax=allRequestsSleepMax,
    )

    # We start the crawler and we end:
    crawler.start()
    crawler.mainThread.join()
    log("End.", logger)






