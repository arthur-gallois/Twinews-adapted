# pew in twittercrawler-venv python ~/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/plotperf.py
# pew in twittercrawler-venv python ~/wm-dist-tmp/TwitterCrawler/twittercrawler/plotperf.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.file import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from webcrawler.crawler import *
from hjwebbrowser.utils import *
from hjwebbrowser.browser import *
from databasetools.mongo import *
from twitterarchiveorg.urlgenerator import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *



def getDistinctValues(collection):
#     if not TEST:
    distinctValues = {}
    for key in distinctKeys:
        distinctValues[key] = collection.collection.distinct(key)
    return distinctValues
#     else:
#         return {
#             "hostname":
#             [
#                 "datascience01",
#                 "tipi57",
#                 "tipi58",
#                 "tipi59",
#                 "tipi61",
#                 "tipi62",
#                 "tipi63",
#             ],
#             "browser":
#             [
#                 "phantomjs",
#                 "chrome",
#             ]
#         }

def extractOneKey(distinctValues):
    if distinctValues is None or len(distinctValues) == 0:
        return []
    else:
        firstKey = list(distinctValues.keys())[0]
        previousCombs = []
        for current in distinctValues[firstKey]:
            previousCombs.append({firstKey: current})
        del distinctValues[firstKey]
        return previousCombs

def getCombinason(distinctValues, previousCombs=None):
    combs = []
    if len(distinctValues) == 0:
        return previousCombs
    if previousCombs is None:
        previousCombs = extractOneKey(distinctValues)
    currentCombs = extractOneKey(distinctValues)
    for previousComb in previousCombs:
        for currentComb in currentCombs:
            combs.append(mergeDicts(previousComb, currentComb))
    return getCombinason(distinctValues, previousCombs=combs)

def convertAllLegends(allLegends):
    newAllLegends = []
    for current in allLegends:
        currentStr = ""
        for key, value in current.items():
            currentStr+= value + "-"
        newAllLegends.append(currentStr[:-1])
    return newAllLegends



import matplotlib.pyplot as plt
import numpy as np
# https://stackoverflow.com/questions/4805048/how-to-get-different-colored-lines-for-different-plots-in-a-single-figure
def generatePNGs(x, allY, allLegends):
    print("x size: " + str(len(x)))
    # We make all string legend:
    allLegends = convertAllLegends(allLegends)
    # We convert all timestamp in dates:
    xLabels = []
    for current in x:
        xLabels.append(timestampToDate(current))
    # We delete all [0, 0, ... ] curves:
    newAllY = []
    newCombs = []
    for i in range(len(allY)):
        currentY = allY[i]
        if currentY != [0] * len(allY[0]):
            newAllY.append(currentY)
            newCombs.append(allLegends[i])
    allY = newAllY
    allLegends = newCombs
    # We plot all curves:
    width = int((10/51) * len(x) + (620/51))
    plt.figure(num=None, figsize=(width, 12), dpi=200, facecolor='w', edgecolor='k')
    for currentY in allY:
        plt.plot(x, currentY)
#     plt.figure(figsize=(400,400))
    # We set the legend:
    plt.legend(allLegends)
    plt.xticks(x, xLabels, rotation='vertical')
    plt.margins(0.2)
    plt.subplots_adjust(bottom=0.15)
    # And finally we show all:
    plt.savefig(tmpDir(subDir="plotperf") + "/" + strToFilename(str(allParams)) + ".png")
#     plt.show()



def getIntervals():
    now = time.time()
    timestampInterval = minutesInterval * 60
    allIntervals = []
    currentInterval = startTimestamp
    while currentInterval < now:
        allIntervals.append(currentInterval)
        currentInterval += timestampInterval
    return allIntervals

def getValues(key, collection):
    distinctValues = getDistinctValues(collection)
    allIntervals = getIntervals()
    combs = getCombinason(distinctValues)
    values = []
    allStartTs = None
    for u in range(len(combs)):
        print(str(truncateFloat(u / len(combs) * 100, 2)) + "%")
        comb = combs[u]
        currentValues = []
        allStartTs = []
        for i in range(len(allIntervals) - window):
            startTs = allIntervals[i]
            endTs = allIntervals[i+window]
            allStartTs.append(startTs)
            restriction = {}
#             if TEST:
#                 restriction = {"scrap.page_state": "loading"}
            query = mergeDicts(restriction, {"timestamp": {"$gte": startTs, "$lt": endTs}}, comb)
            count = collection.collection.count(query)
            currentValues.append(count)
        values.append(currentValues)
    return (allStartTs, values, combs)

import datetime
def timestampToDate(ts):
    # https://stackoverflow.com/questions/3682748/converting-unix-timestamp-string-to-readable-date-in-python
    return datetime.datetime.fromtimestamp(ts).strftime('Le %d/%m à %H:%M')

def plotPerf():
    sd = SerializableDict("plotperf", tmpDir(), funct=getValues,
                          cacheCheckRatio=0.0, limit=100,
                          serializeEachNAction=1)
    printLTS(sd.keys())
#     print("sd size is: " + str(sd.size()))
#     sd.reset()
#     exit()
    collection  = None
    if not sd.has(str(allParams)):
        (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
        collection = MongoCollection \
        (
            "twitter",
            "usercrawl",
            user=user, host=host, password=password,
        )
        indexes = ["timestamp", "browser"]
        collection.createIndexes(indexes, unique=False)
    (allStartTs, values, combs) = sd.get(str(allParams), collection)
    generatePNGs(allStartTs, values, combs)
#     collection.dropIndexes(indexes)



# est ce que quand je met tipi58 tout seul il va plus vite ? le 21 à minuit vs une heure après
# Ouais un peu on dirait

# Est ce que quand je met chrome c'est plus rapide ? matin du 21 vs journée du 21
# Nan 2 fois moins rapide et mange 4 fois plus de proc

# Est ce que tipi 58 est plus rapide que datascience01 ?
# datascience01 vs tipi58 seul: tipi58 est plus rapide
# datascience01 vs la moyenne des tipis: pareil

# Conclusion : obtenir de nouvelle ips et ajouter des tipis



if __name__ == '__main__':
    # (60 * 4, 1) (
    TEST = True
    minutesInterval = 120
#     startTimestamp = 1518980400 # 18 fev à 20h
    startTimestamp = dateToTimestamp("24/02/2018") # 24 fev à 00h
    window = 4
    distinctKeys = ["hostname", "browser"]
    allParams = \
    [
        minutesInterval,
        startTimestamp,
        window,
        distinctKeys,
#         TEST,
    ]
#     from twittercrawler.datatoplot import *
#     generatePNGs(combs, values)
    plotPerf()






