# Page state

 * **backToTop** This state means there is a "Back to top" button at the bottom of the page and that Twitter just stop your scroll because you receive too much tweets... or Twitter doesn't want to display more tweets...
 * **blocked** When "...seems to be taking a while..." at the bottom of the page, meaning there is a poor connexion or Twitter just blocked the crawler
 * **hasMoreItems** It's OK!
 * **hasFewItems** It's OK!
 * **Unknown** You must handle this case
 * **loading** When the page is currently loading content, maybe it's OK, maybe it took too long time to load and the page scroll stopped!

# Date limit

Date limit at the root of json object is the date limit when the scrap was done, and the date_limit in the scrap object can be different if we recalculate on another date...