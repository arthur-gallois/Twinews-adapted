# nn 18 -o nohup-rescrapall.out pew in twittercrawler-venv python ~/wm-dist-tmp/TwitterCrawler/twittercrawler/rescrapall.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from hjwebbrowser.utils import *
from databasetools.mongo import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *
from twittercrawler.utils import *
from datastructuretools.processing import *
from multiprocessing import Pool as MPPool

def countPageStates(collection):
    for current in PAGE_STATE:
        current = current.name
        print(current + " count: " + str(collection.find({"scrap.page_state": current}).count()))

def rescrapRow(id, collection, hus, tus):
    # We get all datas:
    row = collection.findOne({"_id": id, "version": {"$ne": __version__}})
    if row is not None:
        dateLimit = row["date_limit"]
        tus.setDateLimite(dateLimit)
        scrap = row["scrap"]
        log("Parsing " + str(row["url"]), logger)
        html = row["html"]
        hoverUsers = scrap["hover_users"]
        # We get new hover users:
        newHoverUsers = []
        for current in hoverUsers:
            current["scrap"] = hus.parseHoverUser(current["html"])
            newHoverUsers.append(current)
        # We parse the new scrap:
        scrap = tus.scrapUser(html, hoverUsersData=newHoverUsers)
        # Now we delete scrap for this row:
        collection.updateOne({"_id": id}, {"$set": {"scrap": None}})
        # And we set the scrap:
        scrap = dictToMongoStorable(scrap)
        collection.updateOne({"_id": id}, {"$set": {"scrap": scrap}})
        # And finally we set the version:
        collection.updateOne({"_id": id}, {"$set": {"version": __version__}})

def rescrapIds(ids):
    hus = HoverUserScroller(logger=logger, verbose=True)
    tus = TwitterScraper(logger=logger, verbose=True)
    collection = MongoCollection \
    (
        userCrawlDatabase,
        "usercrawl",
        user=user, host=host, password=password,
    )
    for id in ids:
        rescrapRow(id, collection, hus, tus)




def rescrapUserCrawl():
#     if TEST or (input("Are you sure reparse usercrawl ? pls dump the db before. (y/n)") == "y" and \
#     input("Did you stop every crawlers ? (y/n)") == "y"):
    if True:
        collection = MongoCollection \
        (
            userCrawlDatabase,
            "usercrawl",
            user=user, host=host, password=password,
        )
        neRequest = {"version": {"$ne": __version__}}
        allIds = getAllIds(neRequest, collection)
        parallelCount = CPU_COUNT
        allIds = chunks(allIds, parallelCount)
        # We disp some variables to compare:
        log("Starting with all ids...", logger)
#         countPageStates(collection)
        # We get all cursors
        pool = MPPool(parallelCount)
        pool.map(rescrapIds, allIds)
        # Here we check if it remains others versions:
        if collection.has(neRequest):
            logError("It remains old rows", logger)
        else:
            log("All is ok!", logger)
        # We print the ned:
        log("Finished!", logger)
#         countPageStates(collection)

def changeStatus():
    collection = MongoCollection \
    (
        userCrawlDatabase,
        "usercrawl",
        user=user, host=host, password=password,
    )
    collection.update({}, {"$set": {"status": "success"}})

def getAllIds(request, collection):
    allIdsCursor = collection.collection.find(request, {"_id": True})
    allIds = []
    for current in allIdsCursor:
        allIds.append(current["_id"])
    random.shuffle(allIds)
    return allIds

if __name__ == '__main__':
    TEST = isHostname('hjl')
    CPU_COUNT = int(cpuCount() / 8)
    logger = Logger("rescrapall.log")
    logger.log("Starting...")
    if TEST:
        userCrawlDatabase = "test"
        (user, password, host) = getMongoAuth(user=None, hostname="hjlat")
    else:
        userCrawlDatabase = "twitter"
        (user, password, host) = getOctodsMongoAuth()
#     changeStatus()
    rescrapUserCrawl()


