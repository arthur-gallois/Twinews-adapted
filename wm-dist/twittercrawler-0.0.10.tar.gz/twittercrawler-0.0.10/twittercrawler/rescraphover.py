# nn 12 -o nohup-rescraphover.out pew in twittercrawler-venv python ~/wm-dist-tmp/TwitterCrawler/twittercrawler/rescraphover.py

import sys, os; sys.path.append("/".join(os.path.abspath(__file__).split("/")[0:-2]))

from datatools.url import *
from systemtools.basics import *
from systemtools.duration import *
from systemtools.logger import log, logInfo, logWarning, logError, Logger
from systemtools.location import *
from systemtools.hayj import *
from systemtools.system import *
import random
from hjwebbrowser.utils import *
from databasetools.mongo import *
from twittercrawler import __version__
from twittercrawler.twitterscraper import *
from twittercrawler.utils import *
from datastructuretools.processing import *
from multiprocessing import Pool as MPPool


def rescrapHoverUsers():
#     if TEST or (input("Are you sure reparse hovers users ? pls dump the db before. (y/n)") == "y" and \
#     input("Did you stop every crawlers ? (y/n)") == "y"):
    if True:
        collection = MongoCollection \
        (
            "twitter",
            "hoverusers",
            user=user, host=host, password=password,
        )
        # We disp some variables to compare:
        log("Starting hover users rescrap...", logger)
        hus = HoverUserScroller(logger=logger, verbose=True)
        # We get all cursors
        neRequest = {"version": {"$ne": __version__}}
        cursor = collection.find(neRequest)
        for row in cursor:
            try:
                id = row["_id"]
                log("Parsing " + str(row["scrap"]["username"]), logger)
                scrap = hus.parseHoverUser(row["html"])
                # Now we delete scrap for this row:
                collection.updateOne({"_id": id}, {"$set": {"scrap": None}})
                # And we set the scrap:
                scrap = dictToMongoStorable(scrap)
                collection.updateOne({"_id": id}, {"$set": {"scrap": scrap}})
                # And finally we set the version:
                collection.updateOne({"_id": id}, {"$set": {"version": __version__}})
            except Exception as e:
                logException(e, logger, location="for row in cursor")
                logError("FAIL:", logger)
                logError(listToStr(row), logger)
        # Here we check if it remains others versions:
        if collection.has(neRequest):
            logError("It remains old rows", logger)
        else:
            log("All is ok!", logger)
        # We print the ned:
        log("Hover user finished!", logger)



if __name__ == '__main__':
    TEST = False
    logger = Logger("rescrapall.log")
    if TEST:
        userCrawlDatabase = "test"
        (user, password, host) = getMongoAuth(user=None, hostname="hjlat")
    else:
        userCrawlDatabase = "twitter"
        (user, password, host) = getMongoAuth(user="hayj", hostname="datascience01")
    rescrapHoverUsers()


