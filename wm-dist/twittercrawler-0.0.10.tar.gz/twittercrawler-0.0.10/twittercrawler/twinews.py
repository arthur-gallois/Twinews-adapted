# 80
# cd ~/twittercrawler-logs ; killbill twinews ; nn -o nohup-twinews.out pew in st-venv python ~/Workspace/Python/Crawling/TwitterCrawler/twittercrawler/twinews.py

try:
    from systemtools.hayj import *
except: pass
from systemtools.duration import *
from systemtools.basics import *
from systemtools.location import *
from systemtools.file import *
from datastructuretools.hashmap import SerializableDict
from datatools.jsonutils import *
from datatools.dataencryptor import *
import tweepy as tw
import json
import copy
from twittercrawler.mbti.utils import get_all_tweets_per_screen_name

def usernameGenerator(maxUsers=40000, doShuffle=True, logger=None, blackList=set(), verbose=True):
    blackList = copy.copy(blackList)
    count = 0
    pbar = ProgressBar(maxUsers, logger=logger, printRatio=0.00001, verbose=verbose)
    filesPath = sortedGlob(dataDir() + "/TwitterNewsrec/twitternewsrec3/users/*.bz2")
    if doShuffle:
        filesPath = shuffle(filesPath)
    log("Starting twinews iteration...", logger, verbose=verbose)
    for filePath in filesPath:
        for current in NDJson(filePath):
            username = current["username"]
            if username not in blackList:
                yield username
                pbar.tic(username)
                blackList.add(username)
                count += 1
            else:
                log(username + " is in the black list...", logger)
            if maxUsers is not None and count >= maxUsers:
                return

def printSample(count=100):
    print(reducedLTS(list(usernameGenerator(count))))






TEST = False
doShuffle = True
maxUsers = 40000
tweetLimit = 200000
maxSleep = 10
collectionName = "twinews"
if TEST:
    maxUsers = 20
    tweetLimit = 3
    maxSleep = 1
    collectionName = "twinews-test"



twitterKeys = DataEncryptor()["twitterkeys"]["renewal"]
(user, password, host) = getStudentMongoAuth()
sd = SerializableDict(name=collectionName, useMongodb=True, host=host, user=user, password=password, mongoDbName="student")
logger = Logger("twinews.log")
auth = tw.OAuthHandler(twitterKeys['consumer_key'], twitterKeys['consumer_secret'])
auth.set_access_token(twitterKeys['access_token'], twitterKeys['access_token_secret'])
api = tw.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, timeout=200)
log("Starting to get already crawled users...", logger)
blackList = set(sd.keys())
log("We got already crawled user (blacklist) of size: " + str(len(blackList)), logger)
if sd.size() > 0:
    log(". Disp of a random user (a key): " + str(random.choice(list(blackList))), logger)



for username in usernameGenerator(maxUsers=maxUsers, blackList=blackList, doShuffle=doShuffle, logger=logger):
    try:
        if username not in sd:
            log("Getting " + str(username), logger)
            currentData = get_all_tweets_per_screen_name(username, api, limit=tweetLimit)
            statusDicts = []
            for status in currentData:
                statusDicts.append(status._json)
            sd[username] = statusDicts
            randomSleep(maxSleep)
        else:
            log(str(username) + " already crawled..", logger)

    except Exception as e:
        logException(e, logger, message="username: " + username)