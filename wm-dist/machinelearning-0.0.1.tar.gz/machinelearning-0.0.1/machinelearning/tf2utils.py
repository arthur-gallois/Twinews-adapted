"""
    This file is the tensorflow 2 version of kerasutils.py
"""


import tensorflow as tf
from tensorflow.keras.callbacks import Callback
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold, StratifiedKFold
import gc

import logging
import math
try:
    import tensorflow as tf
    from tensorflow.keras import callbacks
    from transformers import DistilBertConfig, DistilBertTokenizer, TFDistilBertForSequenceClassification
except Exception as e:
    print(e)

from systemtools.logger import *
from systemtools.duration import *
from systemtools.basics import *
from systemtools.file import *
from systemtools.location import *
from systemtools.system import *
from systemtools.logger import *
from datatools.jsonutils import *
from machinelearning.utils import *
from machinelearning.iterator import *
from machinelearning.metrics import *


def isCompiled(model):
    try:
        model.optimizer.lr
        return True
    except:
        return False


def getDistilBertRepresentations\
(
    model,
    inputs,
    layer='distilbert', # distilbert, pre_classifier, dropout, classifier
    
):
    """
        get only one input sample
        model is a TFDistilBertForSequenceClassification
        See https://huggingface.co/transformers/_modules/transformers/modeling_tf_distilbert.html#TFDistilBertModel
    """
    distilbert_output = model.distilbert(inputs)
    hidden_state = distilbert_output[0]
    pooled_output = hidden_state[:, 0]
    if layer == 'distilbert':
        return pooled_output
    pooled_output = model.pre_classifier(pooled_output)
    if layer == 'pre_classifier':
        return pooled_output
    pooled_output = model.dropout(pooled_output, training=False)
    if layer == 'dropout':
        return pooled_output
    logits = model.classifier(pooled_output)
    if layer == 'classifier':
        return logits
    else:
        raise Exception("Please choose a layer in ['distilbert', 'pre_classifier', 'dropout', 'classifier']")


distilBertTokenizerSingleton = None
def distilBertEncode\
(
    doc,
    maxLength=512,
    multiSamplage=False,
    multiSamplageMinMaxLengthRatio=0.3,
    bertStartIndex=101,
    bertEndIndex=102,
    preventTokenizerWarnings=False,
    loggerName="transformers.tokenization_utils",
    proxies=None,
    logger=None,
    verbose=True,
):
    """
        Return an encoded doc for DistilBert.
        This function return a list of document parts if you set multiSamplage as True.
    """
    # We set the logger level:
    if preventTokenizerWarnings:
        previousLoggerLevel = logging.getLogger(loggerName).level
        logging.getLogger(loggerName).setLevel(logging.ERROR)
    # We init the tokenizer:
    global distilBertTokenizerSingleton
    if distilBertTokenizerSingleton is None:
        distilBertTokenizerSingleton = DistilBertTokenizer.from_pretrained('distilbert-base-uncased', proxies=proxies)
    tokenizer = distilBertTokenizerSingleton
    # We tokenize the doc:
    if isinstance(doc, list):
        doc = " ".join(doc)
    doc = tokenizer.encode(doc, add_special_tokens=False)
    # In case we want multiple parts:
    if multiSamplage:
        # We chunk the doc:
        parts = chunks(doc, (maxLength - 2))
        # We add special tokens (only one [CLS] at the begining and one [SEP] at the end,
        # even for entire documents):
        parts = [[bertStartIndex] + part + [bertEndIndex] for part in parts]
        # We remove the last part:
        if len(parts) > 1 and len(parts[-1]) < int(maxLength * multiSamplageMinMaxLengthRatio):
            parts = parts[:-1]
        # We pad the last part:
        parts[-1] = parts[-1] + [0] * (maxLength - len(parts[-1]))
        # We check the length of each part:
        for part in parts:
            assert len(part) == maxLength
        # We reset the logger:
        if preventTokenizerWarnings:
            logging.getLogger(loggerName).setLevel(previousLoggerLevel)
        return parts
    # In case we have only one part:
    else:
        # We truncate the doc:
        doc = doc[:(maxLength - 2)]
        # We add special tokens:
        doc = [bertStartIndex] + doc + [bertEndIndex]
        # We pad the doc
        doc = doc + [0] * (maxLength - len(doc))
        # We check the length:
        assert len(doc) == maxLength
        # We reset the logger:
        if preventTokenizerWarnings:
            logging.getLogger(loggerName).setLevel(previousLoggerLevel)
        return doc


AUTO_MODES = \
{
    'val_loss': 'min',
    'val_accuracy': 'max',
    'val_top_k_categorical_accuracy': 'max',
    'val_sparse_categorical_accuracy': 'max',
    'val_sparse_top_k_categorical_accuracy': 'max',
}

class KerasCallback(Callback): # https://github.com/keras-team/keras/blob/master/keras/callbacks.py#L614
    def __init__\
    (
        self,

        model=None,
        directory=None,

        saveFunct=None,
        saveFunctKwargs=None,
        saveMetrics={"val_loss": "min", "val_accuracy": "max",},

        stopFile=None,
        historyFile=None,
        graphsDir=None,
        epochsDir=None,

        showGraphs=False,
        saveGraphs=True,
        saveHistory=True,
        saveEpochs=True,
        logHistory=False,
        doNotif=False,
        removeEpochs=True,

        earlyStopMonitor=None,
        initialEpoch=None,
        batchesAmount=None,
        batchesPassed=0,

        logger=None,
        verbose=True,
    ):
        """
            xVal and yVal can be an InfiniteBatcher instance (see machinelearing.iterator.InfiniteBatcher) or any iterable (np arrays, list, generator, machinelearing.iterator.ConsistentIterator...)

            Example of earlyStopMonitor:
            {
                'val_loss': {'patience': 50, 'min_delta': 0, 'mode': 'min'},
                'val_accuracy': {'patience': 50, 'min_delta': 0.05, 'mode': 'max'},
                'val_top_k_categorical_accuracy': {'patience': 50, 'min_delta': 0, 'mode': 'auto'},
            }
            You have to give at least a patience for each 

            Set batchesPassedFile to save the current batches count until batchesAmount
            Set batchesPassed to start the count from this value
            Usefull to jump some batches in yur batch generator
            set batchesPassedSerializeEach > 1 to do not serialize at each batch
        """
        # Misc vars:
        self.logger = logger
        self.verbose = verbose
        self.tt = TicToc(logger=self.logger, verbose=self.verbose)
        self.alreadyFigured = False

        # The model:
        self.model = model
        self.saveFunct = saveFunct
        self.saveFunctKwargs = saveFunctKwargs
        self.saveMetrics = saveMetrics

        # Events:
        self.showGraphs = showGraphs
        self.saveGraphs = saveGraphs
        self.saveHistory = saveHistory
        self.saveEpochs = saveEpochs
        self.logHistory = logHistory
        self.doNotif = doNotif
        self.removeEpochs = removeEpochs
        if self.saveEpochs and self.model is None:
            raise Exception("Please provide the model in parameters in order to save epochs")

        # Location:
        self.directory = directory
        if self.directory is None:
            self.directory = tmpDir("tf2-models/" + getDateSec())
        mkdir(self.directory)
        self.stopFile = stopFile
        if self.stopFile is None:
            self.stopFile = self.directory + '/stop'
        log('Use this command to stop training: `touch ' + self.stopFile + '`', self)
        self.historyFile = historyFile
        if self.saveHistory:
            if self.historyFile is None:
                self.historyFile = self.directory + '/history.json'
            log('History will be saved in ' + self.historyFile, self)
        self.graphsDir = graphsDir
        if self.saveGraphs:
            if self.graphsDir is None:
                self.graphsDir = self.directory + '/graphs'
            mkdir(self.graphsDir)
            log('Graphs will be saved in ' + self.graphsDir, self)
        self.epochsDir = epochsDir
        if self.saveEpochs:
            if self.epochsDir is None:
                self.epochsDir = self.directory + '/epochs'
            mkdir(self.epochsDir)
            log('Epochs will be saved in ' + self.epochsDir, self)

        # Early stopping:
        self.earlyStopMonitor = earlyStopMonitor
        normalizeEarlyStopMonitor(self.earlyStopMonitor, logger=self.logger, verbose=self.verbose)

        # We load previous states:
        self.initialEpoch = initialEpoch
        if self.historyFile is not None and isFile(self.historyFile):
            historyFileContent = fromJsonFile(self.historyFile)
            self.epochs = historyFileContent["epochs"]
            self.history = historyFileContent["history"]
            logWarning("We loaded previous epochs and history", self)
            if self.initialEpoch is not None:
                previousLength = len(dictFirstValue(self.epochs))
                newLength = len(dictFirstValue(self.epochs)[:self.initialEpoch])
                if previousLength != newLength:
                    logWarning("We reduced the history from a length of " + str(previousLength) + " to a length of " + str(newLength), self)
                    for key in self.epochs.keys():
                        self.epochs[key] = self.epochs[key][:self.initialEpoch]
                    for key in self.history.keys():
                        self.history[key] = self.history[key][:self.initialEpoch]
        else:
            self.epochs = dict()
            self.history = dict()

        # Batch state handling:
        self.batchesAmount = batchesAmount
        self.batchesPassed = batchesPassed

    def saveBatchesPassed(self):
        if self.batchesAmount is not None:
            # Here we set batchesPassed as the number of batches done (already passed):
            self.batchesPassed += 1
            # Then we reset to 0 if all batches passed:
            if self.batchesPassed == self.batchesAmount:
                self.batchesPassed = 0
                log("We passed all batches in the dataset", self)

    def on_batch_end(self, batch, logs={}):
        self.saveBatchesPassed()

    def on_train_begin(self, logs=None):
        self.tt.tic(display=False)
    
    def recordLogs(self, epoch, logs):
        for key, score in logs.items():
            if key not in self.epochs:
                self.epochs[key] = []
                self.history[key] = []
            self.epochs[key].append(epoch)
            self.history[key].append(score)
    
    def __logHistory(self):
        if self.logHistory:
            log("History:\n" + lts(self.history), self) # TODO truncate floats
            log("Last scores:\n" + lts(self.getLastScores()), self)
            
    def plotFigures(self):
        if self.showGraphs or self.saveGraphs:
            try:
                # We find all keys:
                keys = []
                for key in self.epochs.keys():
                    if key.startswith("val"):
                        keys.append(key)
                # We plot all:
                for key in keys:
                    try:
                        if len(self.history[key]) > 1:
                            if not self.alreadyFigured:
                                plt.figure()
                                self.alreadyFigured = True
                            plt.clf()
                            trainKey = None
                            if key[4:] in self.history:
                                trainKey = key[4:]
                            if key in self.history:
                                plt.plot(self.epochs[key], self.history[key])
                                legend = ['Test']
                            if trainKey in self.history:
                                plt.plot(self.epochs[trainKey], self.history[trainKey])
                                legend = ['Test', 'Train']
                            plt.title(key)
                            plt.ylabel('Score')
                            plt.xlabel('Epoch')
                            plt.legend(legend, loc='upper left')
                            if self.saveGraphs:
                                plt.savefig(self.graphsDir + "/" + key + ".png", format='png')
                            if self.showGraphs:
                                plt.show()
                            else:
                                plt.close()
                    except Exception as e:
                        logException(e, self)
            except Exception as e:
                logException(e, self, location="plotFigures")
    
    def isBetterScore(self, key, score, previousScores):
        if not isinstance(previousScores, list):
            previousScores = [previousScores]
        comparisonType = self.saveMetrics[key]
        if comparisonType == "max":
            return score >= max(previousScores)
        elif comparisonType == "min":
            return score <= min(previousScores)
    
    def getLastScores(self):
        lastScores = dict()
        for key, scores in self.history.items():
            lastScores[key] = scores[-1]
        return lastScores

    def saveModel(self, epoch):
        if self.saveEpochs:
            epochToken = digitalizeIntegers(str(epoch), 4)
            foundBetter = False
            lastScores = self.getLastScores()
            for key, scores in self.history.items():
                if len(scores) > 0 and key in self.saveMetrics:
                    currentLastScore = lastScores[key]
                    if self.isBetterScore(key, currentLastScore, scores):
                        foundBetter = True
                        break
            if foundBetter:
                epochDir = self.epochsDir + "/epoch" + epochToken
                mkdir(epochDir)
                # We save the model using a custom function (for exemple machinelearning.kerasmodels.saveModel):
                if self.saveFunct is not None:
                    if self.saveFunctKwargs is None:
                        self.saveFunctKwargs = dict()
                    if 'verbose' not in self.saveFunctKwargs:
                        self.saveFunctKwargs['verbose'] = self.verbose
                    if 'logger' not in self.saveFunctKwargs:
                        self.saveFunctKwargs['logger'] = self.logger
                    self.saveFunct(self.model, epochDir, **self.saveFunctKwargs)
                # Or we just save the model using the keras method:
                else:
                    self.model.save(epochDir + "/model.h5")
                log("We saved the current model in " + epochDir, self)
                toJsonFile(toSerializableJson(lastScores), epochDir + "/scores.json")
                log("We saved scores in " + epochDir + "/scores.json", self)
                # And we serialize batchesPassed:
                if self.batchesAmount is not None:
                    strToFile(str(self.batchesPassed), epochDir + "/batchesPassed.txt")
                    log("We saved batched passed (integer) in " + epochDir + "/batchesPassed.txt", self)
                # Now we remove old models that have all metrics lower than the current:
                if self.removeEpochs:
                    log("Now trying to remove old epochs...", self)
                    log("Previous epochs are: " + lts(sortedGlob(self.epochsDir + "/epoch*")), self)
                    for currentDir in sortedGlob(self.epochsDir + "/epoch*"):
                        if "/epoch" + epochToken not in currentDir:
                            currentScores = fromJsonFile(currentDir + "/scores.json")
                            try:
                                if currentScores is not None:
                                    foundBetter = False
                                    for currentKey, currentScore in currentScores.items():
                                        if currentKey in self.saveMetrics\
                                        and self.isBetterScore(currentKey, currentScore, lastScores[currentKey]):
                                            foundBetter = True
                                            break
                                    if not foundBetter:
                                        log("We remove " + currentDir + " because all scores are lower", self)
                                        remove(currentDir, minSlashCount=4)
                                    else:
                                        log("We do not remove " + currentDir, self)
                                else:
                                    logError("We did not found " + currentDir + "/scores.json", self)
                            except Exception as e:
                                logException(e, self)
                                remove(currentDir, minSlashCount=4, doRaise=False)

    
    def on_epoch_end(self, epoch, logs=None):
        if logs is None:
            logs = dict()
        log("\n", self)
        self.tt.tic("Epoch " + str(epoch) + " done")
        warnFreeRAM(self.logger)
        self.recordLogs(epoch, logs)
        self.__logHistory()
        self.plotFigures()
        self.saveModel(epoch)
        if self.doNotif:
            try:
                notif("Last scores on " + getHostname(), lts(self.getLastScores()))
            except Exception as e:
                logException(e, self)
        if self.historyFile is not None:
            toJsonFile({"epochs": self.epochs, "history": toSerializableJson(self.history)}, self.historyFile)
        if self.stopFile is not None and isFile(self.stopFile):
            self.model.stop_training = True
            log("We stop training because we found " + self.stopFile, self)
        if self.earlyStopMonitor is not None and len(self.earlyStopMonitor) > 0:
            esm = normalizeEarlyStopMonitor(self.earlyStopMonitor, logger=self.logger, verbose=self.verbose)
            if hasToEarlyStop(self.history, esm, logger=self.logger, verbose=self.verbose):
                self.model.stop_training = True
                log("We early stop.", self)
        self.tt.tic("on_epoch_end done")
        self.tt.toc()


def normalizeEarlyStopMonitor(earlyStopMonitor, logger=None, verbose=True):
    esm = dict()
    if earlyStopMonitor is not None:
        for monitor in earlyStopMonitor.keys():
            current = earlyStopMonitor[monitor]
            if not dictContains(current, "patience"):
                raise Exception(monitor + " has no patience")
            if not dictContains(current, "mode") or current["mode"] == 'auto':
                if monitor in AUTO_MODES:
                    current["mode"] = AUTO_MODES[monitor]
                else:
                    raise Exception("Please provide a mode for " + monitor)
            if not dictContains(current, "min_delta"):
                current["min_delta"] = 0.0
            if current["min_delta"] < 0.0:
                raise Exception("min_delta of " + monitor + " must be greater or equal that 0.0")
            esm[monitor] = current
            if monitor in AUTO_MODES and current["mode"] != AUTO_MODES[monitor]:
                logError(monitor + " mode inconsistent... Found " + AUTO_MODES[monitor] + " but got " + current["mode"], logger=logger, verbose=verbose)
    return esm


def hasToEarlyStop(histories, esm, logger=None, verbose=True):
    doStop = True
    for monitor, values in esm.items():
        if monitor in histories.keys():
            history = histories[monitor]
            if len(history) > values["patience"]:
                notEnhancedCount = 0
                index = len(history)
                historyIteration = history[-values["patience"]-1:]
                for targetScore in reversed(historyIteration):
                    index -= 1
                    historyPart = history[:index] # + history[index+1:]
                    if len(historyPart) == 0:
                        break
                    minScore = min(historyPart)
                    maxScore = max(historyPart)
                    if values['mode'] == 'min':
                        if minScore - targetScore >= values['min_delta']:
                            break # We got an enhancment
                    else:
                        if targetScore - maxScore >= values['min_delta']:
                            break # We got an enhancment
                    notEnhancedCount += 1
                if notEnhancedCount <= values["patience"]:
                    doStop = False
                    break
            else:
                doStop = False
                break
        else:
            logError("We didn't found " + monitor + " in the history which contains " + str(list(histories.keys())), logger=logger, verbose=verbose)
            doStop = False
            break
    return doStop


def estimateOptimalEpochs(model, x, y, patience=None,
                          batchSize=128, patienceRatioToKeep=0.3,
                          validationSplit=0.2,
                          logger=None, verbose=True, maxEpochs=10000,
                          kerasVerbose=False):
    if patience is None:
        patience = 10
        logWarning("We will use the default patience " + str(patience), logger, verbose=verbose)
    mainCallback = KerasCallback\
    (
        logger=logger,
        verbose=False,
        earlyStopMonitor=\
        {
            'val_loss': {'patience': patience},
            'val_acc': {'patience': patience},
        },
    )
    history = model.fit\
    (
        x, y,
        validation_split=validationSplit,
        epochs=maxEpochs,
        batch_size=batchSize,
        verbose=1 if kerasVerbose else 0,
        callbacks=[mainCallback],
    )
    epochs = len(history.history[list(history.history.keys())[0]])
    log("Total epochs: " + str(epochs), logger=logger, verbose=verbose)
    epochs = (epochs - patience) + math.ceil(patienceRatioToKeep * patience)
    log("Estimated optimal epochs: " + str(epochs), logger=logger, verbose=verbose)
    return epochs, history

def kerasCrossValidate(x, y, modelBuilder, labelEncoder=None, modelBuilderKwargs=None,
                   patience=10, cv=10, batchSize=128, estimateOptimalEpochsKwargs=None,
                   shuffle=True, randomState=0, logger=None, verbose=True, doPltShow=False,
                   kerasVerbose=False,
                   graphsDir=None,
                   defaultOptimalEpochs=None,
                   # tfBackend=None, clearTF=None,
                   ):
    """
        modelBuilder is a function which must return a keras model.
        modelBuilderKwargs are its parameters.
    """
    if patience <= 1:
        logWarning("The patience is set to " + str(patience) + ", you should set it greater...", logger, verbose=verbose)
    if modelBuilderKwargs is None:
        modelBuilderKwargs = {}
    if estimateOptimalEpochsKwargs is None:
        estimateOptimalEpochsKwargs = {}
    # We propagate estimateOptimalEpochsKwargs:
    assert "patience" not in estimateOptimalEpochsKwargs
    estimateOptimalEpochsKwargs["patience"] = patience
    assert "batchSize" not in estimateOptimalEpochsKwargs
    estimateOptimalEpochsKwargs["batchSize"] = batchSize
    # We split data:
    kfold = StratifiedKFold(n_splits=cv, shuffle=shuffle, random_state=randomState)
    i = 0
    cvScores = []
    pbar = ProgressBar(cv, logger=logger, verbose=verbose)
    if doPltShow or graphsDir is not None:
        plt.figure()
        plt.clf()
    for trainIds, testIds in kfold.split(x, y):
        # We get xTrain, yTrain, xTest and yTest:
        log("Starting kfold " + str(i) + "...", logger, verbose=verbose)
        xTrain = []
        yTrain = []
        for id in trainIds:
            xTrain.append(x[id])
            label = y[id]
            if labelEncoder is not None:
                label = labelEncoder[label]
            yTrain.append(label)
        xTrain = np.array(xTrain)
        yTrain = np.array(yTrain)
        xTest = []
        yTest = []
        for id in testIds:
            xTest.append(x[id])
            label = y[id]
            if labelEncoder is not None:
                label = labelEncoder[label]
            yTest.append(label)
        xTest = np.array(xTest)
        yTest = np.array(yTest)
        # We clean the tf session:
        # if clearTF is not None:
        #     clearTF()
        # if tfBackend is not None:
        #     log("Cleaning tf session...", logger, verbose=verbose)
        #     tfBackend.clear_session()
        optimalEpochs = None
        if defaultOptimalEpochs is not None:
            optimalEpochs = defaultOptimalEpochs
        if optimalEpochs is None:
            # logError("TODO corriger ici, faire 2 variable, une pour les params, une pour la boucle", logger)
            # We get the model:
            model = modelBuilder(**modelBuilderKwargs)
            # We estimate the best amount of epochs:
            optimalEpochs, history = estimateOptimalEpochs\
            (
                model,
                xTrain,
                yTrain,
                logger=logger,
                verbose=False,
                kerasVerbose=kerasVerbose,
                **estimateOptimalEpochsKwargs,
            )
            if doPltShow or graphsDir is not None:
                plt.clf()
                plt.plot(history.history['val_acc'])
                plt.plot(history.history['acc'])
                plt.title('Model accuracy')
                plt.ylabel('Accuracy')
                plt.xlabel('Epoch')
                plt.legend(['Test', 'Train'], loc='upper left')
            if graphsDir is not None:
                plt.savefig(graphsDir + "/" + getDateSec() + ".png", format='png')
            if doPltShow:
                plt.show()
            log("Optimal epochs is: " + str(optimalEpochs), logger, verbose=verbose)
        # We clean the tf session:
        # if clearTF is not None:
        #     clearTF()
        # if tfBackend is not None:
        #     log("Cleaning tf session...", logger, verbose=verbose)
        #     tfBackend.clear_session()
        # We get a new model and train it on all data:
        model = modelBuilder(**modelBuilderKwargs)
        history = model.fit\
        (
            xTrain, yTrain,
            epochs=optimalEpochs,
            batch_size=batchSize,
            verbose=1 if kerasVerbose else 0,
        )
        if doPltShow or graphsDir is not None:
            plt.clf()
            plt.plot(history.history['acc'])
            plt.title('Model accuracy')
            plt.ylabel('Accuracy')
            plt.xlabel('Epoch')
            plt.legend(['Train'], loc='upper left')
        if graphsDir is not None:
            plt.savefig(graphsDir + "/" + getDateSec() + ".png", format='png')
        if doPltShow:
            plt.show()
        # We evaluate the model on the test set:
        scores = model.evaluate(xTest, yTest, verbose=0)
        # We get the acc:
        accIndex = None
        currentIndex = 0
        for key in model.metrics_names:
            if key == "acc":
                accIndex = currentIndex
                break
            currentIndex += 1
        # We clean the tf session:
        # if clearTF is not None:
        #     clearTF()
        # if tfBackend is not None:
        #     log("Cleaning tf session...", logger, verbose=verbose)
        #     tfBackend.clear_session()
        # We take the acc score:
        score = scores[accIndex]
        # We add the current fold score:
        cvScores.append(score)
        # We print end of the fold:
        log("Fold " + str(i) + " done with score: " + str(score), logger, verbose=verbose)
        # We inc the fold:
        i += 1
        pbar.tic("Cross-validation")
    if doPltShow or graphsDir is not None:
        plt.close()
    cvScores = np.array(cvScores)
    currentMean = cvScores.mean()
    currentConfidence = cvScores.std() * 2
    currentResult = {"accuracy": {"score": currentMean, "confidence": currentConfidence}}
    return currentResult
