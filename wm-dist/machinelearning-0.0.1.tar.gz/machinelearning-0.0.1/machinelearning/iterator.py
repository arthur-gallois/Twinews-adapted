from systemtools.basics import *
from systemtools.logger import *
from systemtools.location import *
from datastructuretools.processing import *
from datatools.jsonutils import *
import random
from multiprocessing import cpu_count, Process, Pipe, Queue, JoinableQueue
import queue
import numpy as np
from threading import Lock as TLock
from machinelearning.utils import *


# Enqueue a sentinel object to indicate that there is no more item to consum
# <https://stackoverflow.com/questions/48569731/detect-when-multiprocessing-queue-is-empty-and-closed>


TERMINATED_TOKEN = "__TERMINATED__"
FLUSHED_TOKEN = "__FLUSHED__"
NO_RESULT_TOKEN = "__NO_RESULT__"
DEBUG = False


def Iterator2Generator(*args, **kwargs):
    return IteratorToGenerator(*args, **kwargs)
def IteratorToGenerator(gen):
    for c in gen:
        yield c

class AgainAndAgain():
    # https://www.reddit.com/r/Python/comments/40idba/easy_way_to_make_an_iterator_from_a_generator_in/
    def __init__(self, generator_func, *args, **kwargs):
        self.generator_func = generator_func
        self.args = args
        self.kwargs = kwargs
    def __iter__(self):
        return self.generator_func(*self.args, **self.kwargs)

def iteratorToArray(it, steps=None):
    if it is None:
        return None
    newVal = None
    if isinstance(it, InfiniteBatcher):
        batchs = []
        for i in range(steps):
            current = next(it)
            batchs.append(current)
        if isListOrArray(batchs[0][0]):
            newVal = np.vstack(batchs)
        else:
            newVal = np.array(flattenLists(batchs))
    elif isinstance(it, list):
        newVal = np.array(it)
    elif isinstance(it, np.ndarray):
        newVal = it
    else:
        newVal = []
        for current in it:
            newVal.append(current)
        newVal = np.array(newVal)
    return newVal

def genFunctWrapper\
(
    container,
    itemQueue,
    flushQueue,
    genFunct, genArgs=(), genKwargs={},
    parseFunct=None, parseArgs=(), parseKwargs={},
    verbose=True,
    flushTimeout=5,
    skip=0,
    loggerRoot=None,
    removeLogger=True,
):
    alreadyFirstPush = False
    if loggerRoot is None:
        loggerRoot = tmpDir("mliterator-logs")
    logger = None
    if verbose:
        filename = getHostname() + "-" + getRandomStr() + ".log"
        logger = Logger(loggerRoot + "/" + filename)
    if "logger" not in parseKwargs:
        parseKwargs["logger"] = logger
    if "verbose" not in parseKwargs:
        parseKwargs["verbose"] = verbose
    if DEBUG: log("/".join(container.split("/")[-2:]) + " STARTED", logger)
    try:
        count = 0
        for current in genFunct(container, *genArgs, **genKwargs, logger=logger, verbose=verbose):
            if count >= skip:
                if parseFunct is not None:
                    try:
                        current = parseFunct(current, *parseArgs, **parseKwargs)
                    except Exception as e:
                        logException(e, logger=logger, verbose=verbose)
                        current = None
                if DEBUG:
                    if not alreadyFirstPush:
                        log("/".join(container.split("/")[-2:]) + " FIRST PUSH", logger)
                        alreadyFirstPush = True
                itemQueue.put(current, block=True, timeout=flushTimeout)
                # log(current, logger)
            count += 1
        itemQueue.put(TERMINATED_TOKEN, block=True, timeout=flushTimeout)
        # if DEBUG: log(decomposePath(container)[3] + " TERMINATED", logger)
        if DEBUG: log("/".join(container.split("/")[-2:]) + " TERMINATED", logger)
    except queue.Full:
        flushQueue.put(FLUSHED_TOKEN)
        log("Flushing..." + str(container)[:30], logger)
        # if DEBUG: log(decomposePath(container)[3] + " FLUSHED", logger)
        if DEBUG: log("/".join(container.split("/")[-2:]) + " FLUSHED", logger)
    except Exception as e:
        logException(e, logger=logger, verbose=verbose)
    itemQueue.close()
    flushQueue.close()
    if DEBUG: log("/".join(container.split("/")[-2:]) + " CLOSED", logger)
    if logger is not None and removeLogger:
        logger.remove(minSlashCount=3)
        if getRandomFloat() > 0.95:
            cleanDir(loggerRoot, olderHour=80, endsWith=".log")

class MonoMLIterator: # MonoMLIterator
    def __init__\
    (
        self,
        containers,
        genFunct, genArgs=(), genKwargs={},
        parseFunct=None, parseArgs=(), parseKwargs={},
        topParseFunct=None, topParseArgs=(), topParseKwargs={},
        logger=None, verbose=True, subProcessesVerbose=True,
        parallelProcesses=1, maxParallelProcesses=18,
        queuesMaxSize=100,
        printRatio=0.1, pbarVerbose=True,
        # containerIdFunct=str,
        maxMainLoopCount=200000,
        flushTimeout=5,
        useFlushTimer=False,
    ):
        """
            This class is the same as MultiMLIterator below but no subprocess is used. Thus some init params are useless such as parallelProcesses, maxMainLoopCount, flushTimeout...
        """
        # logging:
        self.logger = logger
        self.verbose = verbose
        self.subProcessesVerbose = subProcessesVerbose
        self.pbarVerbose = pbarVerbose

        # Containers:
        self.containers = containers

        # Generators and parse functs:
        self.genFunct = genFunct
        self.genArgs = genArgs
        self.genKwargs = genKwargs
        self.parseFunct = parseFunct
        self.parseArgs = parseArgs
        self.parseKwargs = parseKwargs
        self.topParseFunct = topParseFunct
        self.topParseArgs = topParseArgs
        self.topParseKwargs = topParseKwargs
        self.parallelProcesses = parallelProcesses

        # Others:
        self.printRatio = printRatio

        # Misc initializations:
        self.pbar = ProgressBar(len(self.containers), logger=self.logger, verbose=self.pbarVerbose and self.verbose, printRatio=self.printRatio)
        self.tlock1 = TLock()
        self.tlock2 = TLock()

        # Loggers:
        if "logger" not in self.genKwargs:
            self.genKwargs["logger"] = self.logger
        if "verbose" not in self.genKwargs:
            self.genKwargs["verbose"] = self.verbose
        if "logger" not in self.parseKwargs:
            self.parseKwargs["logger"] = self.logger
        if "verbose" not in self.parseKwargs:
            self.parseKwargs["verbose"] = self.verbose
        if "logger" not in self.topParseKwargs:
            self.topParseKwargs["logger"] = self.logger
        if "verbose" not in self.topParseKwargs:
            self.topParseKwargs["verbose"] = self.verbose

        # Some logs:
        log(str(len(self.containers)) + " containers to process.", self)
        log("WARNING " * 20 + "We will use MonoMLIterator.", self)

        # Thread queue:
        self.tqueue = queue.Queue(queuesMaxSize)
        self.stop = False
        self.thread = Thread(target=self.__tenqueue)
        self.thread.start()

    def __iter__(self):
        # return self.__gen()
        return self

    def __next__(self):
        with self.tlock1:
            for i in range(1000):
                try:
                    return self.tqueue.get(block=False)
                except:
                    if self.stop:
                        raise StopIteration
                    time.sleep(0.01)
            raise Exception("Cannot give next element")

    def __tenqueue(self):
        try:
            with self.tlock2:
                for container in self.containers:
                    try:
                        for row in self.genFunct(container, *self.genArgs, **self.genKwargs):
                            if self.parseFunct is not None:
                                try:
                                    row = self.parseFunct(row, *self.parseArgs, **self.parseKwargs)
                                except Exception as e:
                                    logException(e, self)
                            if self.topParseFunct is not None:
                                try:
                                    row = self.topParseFunct(row, *self.topParseArgs, **self.topParseKwargs)
                                except Exception as e:
                                    logException(e, self)
                            self.tqueue.put(row, block=True, timeout=None)
                    except Exception as e:
                        logException(e, self)
                    self.pbar.tic()
                self.stop = True
        except Exception as e:
            logException(e, self)


class MLIterator: # MultiMLIterator
    def __init__\
    (
        self,
        containers,
        genFunct, genArgs=(), genKwargs={},
        parseFunct=None, parseArgs=(), parseKwargs={},
        topParseFunct=None, topParseArgs=(), topParseKwargs={},
        logger=None, verbose=True, subProcessesVerbose=True,
        parallelProcesses=1, maxParallelProcesses=18,
        queuesMaxSize=100,
        printRatio=0.1, pbarVerbose=True,
        # containerIdFunct=str,
        maxMainLoopCount=100000,
        mainLoopWait=1,
        flushTimeout=5,
        useFlushTimer=False,
    ):
        """
            This Iterator takes containers that can be, for instance, files path.
            It takes genFunct (generator function) that must yield items (for instance rows of a file). Don't forgot to declare `*args, **kwargs` in all given functions. genFunct runs in a subprocess, so vars in parseArgs and parseKwargs must be serializable.
            parseFunct is a function that is intended to parse an item (a row of a file). It is executed in a subprocess so vars in parseArgs and parseKwargs must be serializable. The parseFunct can be time consuming because it will be executed on multiple cores.
            topParseFunct is executed after parseFunct but in the top process.
            flushTimeout (default 5) allow you to do not keep a file loaded in memory because just stop to iterate over genFunct if the queue is full and no case is released until 5 seconds. It also allow sub processes to finish even all items were not consumed. Of course if a genFunct iteration is flushed, the iterator will iterate again over the same container but will skip previous consumed items.
            You can wrap an instance of MLIterator in AgainAndAgain, so your iterator can be restarted again and again... For example for Gensim Doc2Vec.
            You can wrap the AgainAndAgain over InfiniteBatcher, for example for Keras fit_generator
            WARNING: With parallelProcesses > 1, this iterator is not consistent, meaning 2 iterations over same containers will not give items in the same order. For example when you iterate to get data and iterate again to get labels...
            See examples in ./test/mliterator-test.py
        """
        # logging:
        self.logger = logger
        self.verbose = verbose
        self.subProcessesVerbose = subProcessesVerbose
        self.pbarVerbose = pbarVerbose

        if parallelProcesses > 1:
            logWarning("With parallelProcesses > 1, this iterator is not consistent, meaning 2 iterations over same containers will not give items in the same order", self)

        # Containers:
        self.containers = containers

        # Generators and parse functs:
        self.genFunct = genFunct
        self.genArgs = genArgs
        self.genKwargs = genKwargs
        self.parseFunct = parseFunct
        self.parseArgs = parseArgs
        self.parseKwargs = parseKwargs
        self.topParseFunct = topParseFunct
        self.topParseArgs = topParseArgs
        self.topParseKwargs = topParseKwargs
        self.parallelProcesses = parallelProcesses

        # Processes conf:
        self.parallelProcesses = parallelProcesses
        if self.parallelProcesses < 1:
            self.parallelProcesses = 1
        if self.parallelProcesses > maxParallelProcesses:
            self.parallelProcesses = maxParallelProcesses
        if self.parallelProcesses > len(containers):
            self.parallelProcesses = len(containers)

        # Others:
        self.queuesMaxSize = queuesMaxSize
        if self.queuesMaxSize < 1:
            self.queuesMaxSize = 1
        self.printRatio = printRatio
        self.maxMainLoopCount = maxMainLoopCount
        self.mainLoopWait = mainLoopWait
        self.flushTimeout = flushTimeout
        # self.containerIdFunct = containerIdFunct

        # Initialization of containers lists:
        self.remaining = [] # container, skip
        for container in containers:
            self.remaining.append((container, 0))

        # Initialization of queues
        self.itemQueues = [None] * self.parallelProcesses
        self.flushQueues = [None] * self.parallelProcesses
        self.pending = [None] * self.parallelProcesses
        self.consumedCount = [None] * self.parallelProcesses
        self.processes = [None] * self.parallelProcesses
        self.index = 0

        # Misc initializations:
        self.pbar = ProgressBar(len(self.containers), logger=self.logger, verbose=self.pbarVerbose and self.verbose, printRatio=self.printRatio)
        self.tlock = TLock()

        # Loggers:
        if "logger" not in self.topParseKwargs:
            self.topParseKwargs["logger"] = self.logger
        if "verbose" not in self.topParseKwargs:
            self.topParseKwargs["verbose"] = self.verbose

        # Some logs:
        log(str(len(self.containers)) + " containers to process.", self)

        # Flush timer:
        self.useFlushTimer = useFlushTimer
        self.flushTimer = None
        if self.useFlushTimer:
            self.flushTimer = Timer(self.__cleanProcesses, 0.3, sleepFirst=True)
            self.flushTimer.start()


    def __iter__(self):
        return self

    def __cleanProcesses(self):
        with self.tlock:
            for index in range(len(self.flushQueues)):
                if self.flushQueues[index] is not None:
                    try:
                        flushToken = self.flushQueues[index].get(block=False, timeout=None)
                        if flushToken == FLUSHED_TOKEN:
                            # We delete all but we add the current container in remaining with the right skip:
                            container = self.pending[index]
                            self.itemQueues[index].close()
                            self.itemQueues[index] = None
                            self.flushQueues[index].close()
                            self.flushQueues[index] = None
                            self.pending[index] = None
                            self.remaining.append((container, self.consumedCount[index]))
                            self.consumedCount[index] = None
                            log("/".join(container.split("/")[-2:]) + " joining", self)
                            self.processes[index].join()
                            # self.processes[self.index].close() # Python 3.8
                            self.processes[index] = None
                            log("/".join(container.split("/")[-2:]) + " join done", self)
                        else:
                            raise Exception("Unknown token")
                    except queue.Empty:
                        pass


    def __next__(self):
        result = NO_RESULT_TOKEN
        with self.tlock:
            mainLoopCount = 0
            while isinstance(result, type(NO_RESULT_TOKEN)) and result == NO_RESULT_TOKEN:
                # We check if we finished:
                if len(self.remaining) == 0:
                    foundNotNone = False
                    for current in self.itemQueues:
                        if current is not None:
                            foundNotNone = True
                    if not foundNotNone:
                        if self.flushTimer is not None:
                            self.flushTimer.stop()
                        raise StopIteration
                # If the current box is empty:
                if self.itemQueues[self.index] is None:
                    # If we have remaining containers:
                    if len(self.remaining) > 0:
                        # We create queues:
                        self.itemQueues[self.index] = Queue(self.queuesMaxSize)
                        self.flushQueues[self.index] = Queue()
                        # We sort remaining container according to the skip param:
                        self.remaining = sorted(self.remaining, key=lambda x: x[1])
                        # We take a container:
                        container, skip = self.remaining.pop()
                        self.pending[self.index] = container
                        self.consumedCount[self.index] = skip
                        # We create the process:
                        p = Process\
                        (
                            target=genFunctWrapper,
                            args=\
                            (
                                container,
                                self.itemQueues[self.index],
                                self.flushQueues[self.index],
                                self.genFunct
                            ),
                            kwargs=\
                            {
                                "genArgs": self.genArgs,
                                "genKwargs": self.genKwargs,
                                "parseFunct": self.parseFunct,
                                "parseArgs": self.parseArgs,
                                "parseKwargs": self.parseKwargs,
                                "verbose": self.subProcessesVerbose,
                                "flushTimeout": self.flushTimeout,
                                "skip": skip,
                            },
                        )
                        p.start()
                        self.processes[self.index] = p
                    # Else if we have no remaining containers:
                    else:
                        pass
                else:
                    # First we check if we can get something in the item queue:
                    try:
                        result = self.itemQueues[self.index].get(block=False, timeout=None)
                        if result == TERMINATED_TOKEN:
                            # We just delete all:
                            container = self.pending[self.index]
                            self.itemQueues[self.index].close()
                            self.itemQueues[self.index] = None
                            self.flushQueues[self.index].close()
                            self.flushQueues[self.index] = None
                            self.pending[self.index] = None
                            self.consumedCount[self.index] = None
                            self.pbar.tic() # str(container)
                            result = NO_RESULT_TOKEN
                            self.processes[self.index].join()
                            # self.processes[self.index].close() # Python 3.8
                            self.processes[self.index] = None
                        else:
                            if self.topParseFunct is not None:
                                result = self.topParseFunct(result, *self.topParseArgs, **self.topParseKwargs)
                            self.consumedCount[self.index] += 1
                    # If there is no item:
                    except queue.Empty:
                        # We just pass:
                        try:
                            flushToken = self.flushQueues[self.index].get(block=False, timeout=None)
                            if flushToken == FLUSHED_TOKEN:
                                # We delete all but we add the current container in remaining with the right skip:
                                container = self.pending[self.index]
                                self.itemQueues[self.index].close()
                                self.itemQueues[self.index] = None
                                self.flushQueues[self.index].close()
                                self.flushQueues[self.index] = None
                                self.pending[self.index] = None
                                self.remaining.append((container, self.consumedCount[self.index]))
                                self.consumedCount[self.index] = None
                                # self.processes[self.index].join()
                                # self.processes[self.index].close() # Python 3.8
                                self.processes[self.index] = None
                            else:
                                raise Exception("Unknown token")
                        except queue.Empty:
                            pass
                # We check we we looped too much:
                mainLoopCount += 1
                if mainLoopCount % self.maxMainLoopCount == 0:
                    # logError("The main loop of " + str(self.__class__.__name__) + " had no result more than " + str(self.maxMainLoopCount) + " times. Maybe du to a large skip in subprocesses. We will wait " + str(self.mainLoopWait) + " second(s).", self)
                    time.sleep(self.mainLoopWait)
                # We inc the index:
                self.index += 1
                if self.index == len(self.itemQueues):
                    self.index = 0
        # We return the result:
        return result



class InfiniteBatcher:
    """
        This class takes an AgainAndAgain iterator and yield batch samples
        An AgainAndAgain iterator is an iterator that calling `iter(instance)` or `for i in instance`
        will produce a new fresh iterator to be able to iterate again and again...

        Each tuple which is yield by the iterator given will be transformed in batchs.
        It means instead of return (a, b) then (c, d) then (e, f) (from the AgainAndAgain instance)
        it wil return, for a bacth size of 2, ([a, c], [b, d]) then ([e], [f]) then ([a, c], [b, d]) then ([e], [f]) etc infinitely without StopIteration, which mean without the need to call `for i in instance` several time.

        It will automatically detect if yielded elements are tuples... This mean if your againAndAgainIterator doesn't yield tuples, the infinite batcher will simply yield batches of elements instead of batches of tuples.

        This class is usefull to create generators for keras `fit_generator`.

        To pass an InfiniteBatcher to keras `fit_generator` you must first count the number of samples and call `history = model.fit_generator(myInfiniteBatcher, steps_per_epoch=math.ceil(trainSamplesCount / myInfiniteBatcher.batchSize)` 
        
        Use shuffle=1 to shuffle each bacthes. If shuffle > 1, multiple batches will be flattened, shuffled, re-splitted and returned... If shuffle is None or 0, no shuffling will be applied.

        Use skip to skip n batches, typically usefull when you resume a deep learning training from a previous train (to do not start allways at the beggining of the dataset if you resume your training again and again...)

        Use queueSize > 1 to pre-load batches

        TODO param `fillBatches` which never let a batch had a len lower that the batch size (typically when the end of the dataset arrive with a StopIteration)

        EXAMPLE FOR TensorFlow 2 :

        train = IteratorToGenerator(InfiniteBatcher\
        (
            AgainAndAgain(ksetGen, **ksetGenTrainKwargs),
            batchSize=config['batchSize'],
            shuffle=config['shuffle'],
            queueSize=config['queueSize'],
            skip=batchesPassed,
            logger=logger,
        ))

    """
    def __init__\
    (
        self,
        againAndAgainIterator,
        batchSize=128,
        skip=0,
        shuffle=0,
        seed=0,
        toNumpyArray=True,
        queueSize=1,
        logger=None,
        verbose=True,
    ):
        # assert isinstance(againAndAgainIterator, AgainAndAgain) or isinstance(againAndAgainIterator, list)
        # if isinstance(againAndAgainIterator, list):
        #     againAndAgainIterator = iter(againAndAgainIterator)
        assert isinstance(againAndAgainIterator, AgainAndAgain)
        self.logger = logger
        self.verbose = verbose
        self.skip = skip
        if self.skip is None:
            self.skip = 0
        self.shuffle = shuffle
        if self.shuffle is None or self.shuffle < 0:
            self.shuffle = 0
        self.againAndAgainIterator = againAndAgainIterator
        self.toNumpyArray = toNumpyArray
        self.batchSize = batchSize
        self.currentGenerator = None
        self.tlock = TLock()
        self.queueSize = queueSize
        if self.queueSize < 1:
            self.queueSize = 1
        self.seed = seed
        self.rd = random.Random(self.seed)
        self.queue = queue.Queue()

    def __iter__(self):
        return self

    def __next__(self):
        with self.tlock:
            while self.queue.qsize() < self.queueSize:
                self.__enqueue()
            return self.queue.get()

    def __enqueue(self):
        try:
            batches = []
            if self.shuffle == 0 or self.shuffle == 1:
                nbBatches = 1
            else:
                nbBatches = self.shuffle
            gotStop = False
            while len(batches) < nbBatches and not gotStop:
                if self.currentGenerator is None:
                    self.currentGenerator = iter(self.againAndAgainIterator)
                batch = None
                try:
                    for i in range(self.batchSize):
                        current = next(self.currentGenerator)
                        if batch is None:
                            batch = []
                        if current is not None:
                            batch.append(current)
                except StopIteration:
                    self.currentGenerator = None
                    self.rd = random.Random(self.seed)
                    gotStop = True
                if batch is not None and len(batch) > 0:
                    batches.append(batch)
            if self.shuffle > 0:
                tmpBatchesLen = len(batches)
                batches = flattenLists(batches)
                self.rd.shuffle(batches)
                batches = split(batches, tmpBatchesLen)
            isTuple = False
            try:
                isTuple = isinstance(batches[0][0], tuple)
            except: pass
            if isTuple:
                newBatches = []
                for u in range(len(batches)):
                    batch = []
                    for i in range(len(batches[0][0])):
                        batch.append([])
                    newBatches.append(batch)
                batchIndex = 0
                for batch in batches:
                    for currentTuple in batch:
                        tupleIndex = 0
                        for element in currentTuple:
                            newBatches[batchIndex][tupleIndex].append(element)
                            tupleIndex += 1
                    batchIndex += 1
                batches = newBatches
            if self.toNumpyArray:
                for u in range(len(batches)):
                    if isTuple:
                        for i in range(len(batches[u])):
                            batches[u][i] = np.array(batches[u][i])
                    else:
                        batches[u] = np.array(batches[u])
            if isTuple:
                for i in range(len(batches)):
                    batches[i] = tuple(batches[i])
            for batch in batches:
                if self.skip == 0:
                    self.queue.put(batch)
                else:
                    self.skip -= 1
        except Exception as e:
            logException(e, self, location="InfiniteBatcher")





