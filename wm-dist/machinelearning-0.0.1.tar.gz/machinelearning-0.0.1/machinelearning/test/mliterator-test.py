
# killbill mliterator ; nn pew in st-venv python ~/Workspace/Python/Utils/MachineLearning/machinelearning/test/mliterator-test.py ; observe nohup.out
# killbill mliterator ; pew in st-venv python ~/Workspace/Python/Utils/MachineLearning/machinelearning/test/mliterator-test.py

import os
import sys


import unittest
import doctest
from systemtools.basics import *
from systemtools.location import *
from systemtools.printer import *
from machinelearning import iterator
from machinelearning.iterator import *
import numpy as np

# The level allow the unit test execution to choose only the top level test
mini = 0
maxi = 10
assert mini <= maxi

print("==============\nStarting unit tests...")

if mini <= 0 <= maxi:
    class DocTest(unittest.TestCase):
        def testDoctests(self):
            """Run doctests"""
            doctest.testmod(iterator)


if mini <= 1 <= maxi:
    class Test1(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            def genFunct(container, *args, **kwargs):
                with open(container, "r") as f:
                    for line in f:
                        yield line
            def parseFunct(item, *args, **kwargs):
                return item.strip() * 5
            files = sortedGlob(execDir(__file__) + "/data/1/*.txt")
            # for current in genFunct(files[0]):
            #     print(current)
            mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct)
            c = 0
            for current in mli:
                c += 1
                print(current)
            self.assertTrue(c == 26)



# if mini <= 1 <= maxi:
#     class Test1(unittest.TestCase):
#         def test1(self):
#             def genFunct(container, *args, **kwargs):
#                 with open(container, "r") as f:
#                     for line in f:
#                         yield line
#             def parseFunct(item, *args, **kwargs):
#                 return item.strip() * 5
#             files = sortedGlob(execDir(__file__) + "/data/1/*.txt")
#             # for current in genFunct(files[0]):
#             #     print(current)
#             mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct)


#             # aaa = AgainAndAgain(MonoMLIterator, files, genFunct=genFunct, parseFunct=parseFunct)

#             # for current in mli:
#             #     print(current)

#             # for current in mli:
#             #     print(current)

#             # for current in mli:
#             #     print(current)

#             # ii = iter(mli)

#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))


#             # ii = iter(mli)
#             # print("SUIVANT")
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))
#             # bp(next(ii))


#             c = 0
#             for current in mli:
#                 c += 1
#                 print(current)
#             self.assertTrue(c == 26)

if mini <= 2 <= maxi:
    class Test2(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            verbose = False
            for i in pb(list(range(10))):
                for parallelProcesses in [0, 5, 100]: # [0, 5, 100]
                    for queuesMaxSize in [0, 2, 1000]: # [0, 2, 1000]
                        for flushTimeout in [0.1, 0.001]:
                            def genFunct(container, *args, **kwargs):
                                with open(container, "r") as f:
                                    for line in f:
                                        yield line
                            def parseFunct(item, *args, **kwargs):
                                return item.strip() * 5
                            files = sortedGlob(execDir(__file__) + "/data/1/*.txt")
                            mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, queuesMaxSize=queuesMaxSize, parallelProcesses=parallelProcesses, flushTimeout=flushTimeout, verbose=verbose)
                            c = 0
                            elements = set()
                            elementsList = []
                            for current in mli:
                                elements.add(current)
                                elementsList.append(current)
                                log("1 --> " + current, verbose=verbose)
                                c += 1
                                if c == 5:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                elementsList.append(current)
                                log("2 --> " + current, verbose=verbose)
                                c += 1
                                if c == 10:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                elementsList.append(current)
                                log("3 --> " + current, verbose=verbose)
                                c += 1
                                if c == 15:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                elementsList.append(current)
                                log("4 --> " + current, verbose=verbose)
                                c += 1
                            # print("TTTTTTTTTTTT")
                            bp(elements, verbose=verbose)
                            # bp(elementsList, 5)
                            # print("TTTTTTTTTTTT")
                            self.assertTrue(c == 26)
                            self.assertTrue(len(elements) == 26)



if mini <= 3 <= maxi:
    class Test3(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            verbose = True
            for i in pb(list(range(1))):
                for parallelProcesses in [5]: # [0, 5, 100]
                    for queuesMaxSize in [2]: # [0, 2, 1000]
                        for flushTimeout in [2]:
                            def genFunct(container, *args, **kwargs):
                                with open(container, "r") as f:
                                    for line in f:
                                        yield line
                            def parseFunct(item, *args, **kwargs):
                                randomSleep(0.001, 0.1)
                                return item.strip() * 5
                            files = sortedGlob(execDir(__file__) + "/data/1/*.txt")
                            mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, queuesMaxSize=queuesMaxSize, parallelProcesses=parallelProcesses, flushTimeout=flushTimeout, verbose=verbose)
                            c = 0
                            elements = set()
                            for current in mli:
                                elements.add(current)
                                log("1 --> " + current, verbose=verbose)
                                c += 1
                                if c == 5:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                log("2 --> " + current, verbose=verbose)
                                c += 1
                                if c == 10:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                log("3 --> " + current, verbose=verbose)
                                c += 1
                                if c == 15:
                                    break
                            time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                log("4 --> " + current, verbose=verbose)
                                c += 1
                            bp(elements, verbose=verbose)
                            self.assertTrue(c == 26)
                            self.assertTrue(len(elements) == 26)



if mini <= 4 <= maxi:
    class Test4(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            verbose = False
            for parallelProcesses in [5]: # [0, 5, 100]
                for queuesMaxSize in [2]: # [0, 2, 1000]
                    for flushTimeout in [2]:
                        def genFunct(container, *args, **kwargs):
                            with open(container, "r") as f:
                                for line in f:
                                    yield line
                        def parseFunct(item, *args, **kwargs):
                            return item.strip() * 5
                        def topParseFunct(item, a, *args, **kwargs):
                            return item[:2] + a
                        files = sortedGlob(execDir(__file__) + "/data/1/*.txt")
                        mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, queuesMaxSize=queuesMaxSize, parallelProcesses=parallelProcesses, flushTimeout=flushTimeout, verbose=verbose, topParseFunct=topParseFunct, topParseArgs=("-",))
                        c = 0
                        elements = set()
                        for current in mli:
                            elements.add(current)
                            log("1 --> " + current, verbose=verbose)
                            c += 1
                            if c == 5:
                                break
                        # time.sleep(flushTimeout * 2)
                        # for current in mli:
                        #     elements.add(current)
                        #     log("1 --> " + current, verbose=verbose)
                        #     c += 1
                        #     if c == 10:
                        #         break
                        self.assertTrue(c == 5)
                        self.assertTrue(len(elements) == 5)
                        print("DOES THE Test3 end correctly (or there are zombie processes) ?")



if mini <= 5 <= maxi:
    class Test5(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            verbose = False
            theDir = execDir(__file__) + "/data/tmp"
            nbTests = 2
            for i in pb(list(range(nbTests))):
                if nbTests < 10:
                    print("WARNING nbTests is very low")
                def genFunct(container, *args, **kwargs):
                    with open(container, "r") as f:
                        for line in f:
                            yield line
                def parseFunct(item, *args, **kwargs):
                    return item.strip() * 5
                nbRows = getRandomInt(10, 10000)
                nbRowsPerFile = getRandomInt(1, 100)
                print("nbRows: " + str(nbRows))
                print("nbRowsPerFile: " + str(nbRowsPerFile))
                if isDir(theDir):
                    remove(theDir)
                mkdir(theDir)
                currentFileIndex = 1
                currentNbRows = 0
                currentFile = None
                for i in range(nbRows):
                    if currentFile is None or currentNbRows >= nbRowsPerFile:
                        if currentFile is not None:
                            currentFile.close()
                        currentFile = open(theDir + "/" + str(currentFileIndex) + ".txt", "a")
                        currentFileIndex += 1
                        currentNbRows = 0
                    currentFile.write(getRandomStr() + "\n")
                    currentNbRows += 1
                currentFile.close()
                files = sortedGlob(theDir + "/*.txt")
                for parallelProcesses in [0, 100]: # [0, 5, 100]
                    for queuesMaxSize in [0, 100]: # [0, 2, 1000]
                        for flushTimeout in [0.001]: # [0.1, 0.001]
                            mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, queuesMaxSize=queuesMaxSize, parallelProcesses=parallelProcesses, flushTimeout=flushTimeout, verbose=verbose)
                            c = 0
                            elements = set()
                            for i in range(getRandomInt(20, 10000)):
                                currentMaxCount = getRandomInt(10, 1000)
                                currentCount = 0
                                for current in mli:
                                    elements.add(current)
                                    c += 1
                                    currentCount += 1
                                    if currentCount == currentMaxCount:
                                        break
                                time.sleep(flushTimeout * 2)
                            for current in mli:
                                elements.add(current)
                                c += 1
                            self.assertTrue(c == nbRows)
                            self.assertTrue(len(elements) == nbRows)
                            print("ok")
            if isDir(theDir):
                remove(theDir)




if mini <= 7 <= maxi:
    class Test7(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            verbose = True
            for i in pb(list(range(1))):
                for parallelProcesses in [5]: # [0, 5, 100]
                    for queuesMaxSize in [2]: # [0, 2, 1000]
                        for flushTimeout in [2]:
                            def genFunct(container, *args, **kwargs):
                                with open(container, "r") as f:
                                    for line in f:
                                        yield line
                            def parseFunct(item, *args, **kwargs):
                                randomSleep(0.00001, 0.1)
                                return item.strip() * 5
                            files = sortedGlob(execDir(__file__) + "/data/2/*.txt")
                            # mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, queuesMaxSize=queuesMaxSize, parallelProcesses=parallelProcesses, flushTimeout=flushTimeout, verbose=verbose)

                            aaa = AgainAndAgain\
                            (
                                MLIterator,
                                files,
                                genFunct=genFunct,
                                parseFunct=parseFunct,
                                queuesMaxSize=queuesMaxSize,
                                parallelProcesses=parallelProcesses,
                                flushTimeout=flushTimeout,
                                verbose=verbose
                            )

                            ib = InfiniteBatcher\
                            (
                                aaa,
                                shuffle=10,
                                queueSize=10,
                                skip=10,
                            )

                            current = None
                            c = 0
                            for i in range(100):
                                current = next(ib)
                                bp(current)
                                c += 1
                            self.assertTrue(current is not None)
                            self.assertTrue(c > 90)
                            print("DOES THE Test7 end correctly (or there are zombie processes) ?")




if mini <= 8 <= maxi:
    class Test8(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            files = sortedGlob(tmpDir("citest") + "/*.bz2")
            self.assertTrue(len(files) > 8)
            from newssource.asa.asapreproc import buildASAP
            logger = Logger()
            asap = buildASAP\
            (
                files,
                persist=[False],
                logger=logger,
                verbose=True,
                prebuilt=tmpDir("citest") + "/prebuilt.pickle",
            )
            # asap.serializePrebuilt(tmpDir("citest") + "/prebuilt.pickle")
            c = 0
            batch = None
            ib = asap.getInfiniteBatcher(skip=0, shuffle=0)
            for i in pb(list(range(30)), logger=logger, message="InfiniteBatcher"):
                batch = next(ib)
                c += 1
            bp(batch, logger)
            log("DOES THE Test8 end correctly (or there are zombie processes) ?", logger)





if mini <= 11 <= maxi:
    class Test11(unittest.TestCase):
        def test1(self):
            print("#" * 20 + "STARTING " + str(self.__class__.__name__))
            def genFunct(container, *args, **kwargs):
                with open(container, "r") as f:
                    for line in f:
                        yield line
            def parseFunct(item, *args, **kwargs):
                randomSleep(0.000001, 0.001)
                return item.strip() * 5
            for parallelProcesses in pb([1, 1, 1, 10, 18, 300]):
                datas = []
                for i in range(1000):
                    files = sortedGlob(execDir(__file__) + "/data/2/*.txt")
                    mli = MLIterator(files, genFunct=genFunct, parseFunct=parseFunct, parallelProcesses=parallelProcesses, verbose=False)
                    c = 0
                    els = []
                    for current in mli:
                        c += 1
                        els.append(current)
                    datas.append(els)
                foundDifferent = False
                for current in range(1, len(datas)):
                    if datas[1] != datas[0]:
                        foundDifferent = True
                        break
                if parallelProcesses == 1:
                    self.assertTrue(not foundDifferent)
                else:
                    self.assertTrue(foundDifferent)




if __name__ == '__main__':
    unittest.main()


print("Unit tests done.\n==============")